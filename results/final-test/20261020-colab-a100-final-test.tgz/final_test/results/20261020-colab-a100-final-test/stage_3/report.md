# Stage 3: KV-cache compression

Run started 2026-10-21 18:27:12.

## Summary

Our method is a trade-off against the standard method: better on some measures, worse on others (better on short-term memory needed for one long text, storage used per number in the notes; worse on prediction error on test text (validation half), time to read the prompt, time to write each word). It costs more to prepare: time to prepare the compressed model (0.000107 s more, paid once). Our method is a trade-off against the standard method: better on some measures, worse on others (better on short-term memory needed for one long text, storage used per number in the notes; worse on prediction error on test text (validation half)). It costs more to prepare: time to prepare the compressed model (1.05e-05 s more, paid once). Our method is a trade-off against the standard method: better on some measures, worse on others (better on short-term memory needed for one long text, storage used per number in the notes; worse on prediction error on test text (validation half), time to read the prompt, time to write each word). It costs more to prepare: time to prepare the compressed model (0.746 s more, paid once). Our method is a trade-off against the standard method: better on some measures, worse on others (better on short-term memory needed for one long text, storage used per number in the notes; worse on prediction error on test text (validation half), time to read the prompt, time to write each word). It costs more to prepare: time to prepare the compressed model (0.000356 s more, paid once). Our method is a trade-off against the standard method: better on some measures, worse on others (better on short-term memory needed for one long text, storage used per number in the notes; worse on prediction error on test text (validation half), time to read the prompt, time to write each word). It costs more to prepare: time to prepare the compressed model (0.000375 s more, paid once). Our method is a trade-off against the standard method: better on some measures, worse on others (better on prediction error on test text (validation half), short-term memory needed for one long text, storage used per number in the notes; worse on time to read the prompt, time to write each word). It costs more to prepare: time to prepare the compressed model (0.000314 s more, paid once).

## Original model

Every version in this report starts from this model, unchanged as published.

| What | Value | What it means |
|---|---|---|
| Model | TinyLlama/TinyLlama-1.1B-Chat-v1.0 | The published model every result in this report starts from. |
| Architecture | LlamaForCausalLM | The model family's design; models of the same family are built the same way. |
| Parameters | 1,100,048,384 (1.10 billion) | How many numbers the model has learned. More numbers usually means a more capable but bigger and slower model. |
| Layers | 22 | How many similar building blocks the text passes through, one after another. Stage 0 measures each one separately. |
| Hidden size | 2,048 | How many numbers describe each word inside the model, as it passes from layer to layer. |
| Feed-forward size | 5,632 | How wide the "thinking" part inside each layer is, in numbers per word. |
| Attention heads | 32 | How many separate ways each layer looks back at earlier words at the same time. |
| Key/value heads | 4 | How many sets of notes each layer stores about earlier words (the KV cache). Fewer than the attention heads means the notes are shared, which saves memory. |
| Numbers per head | 64 | How many numbers each attention head uses per word. |
| Vocabulary | 32,000 | How many different word pieces (tokens) the model knows. |
| Maximum context | 2,048 tokens | The most tokens (word pieces) the model can read and write at once. |
| Published number format | bfloat16 | How the numbers are stored in the published model files. |
| Bits per number | 16 bits | Storage per number in the uncompressed model; compression lowers this. |
| Size at 16 bits | 2.20 GB | Memory the numbers take in the uncompressed 16-bit format (parameters x 2 bytes). |
| Input and output word tables shared | no | Whether the table turning words into numbers is reused to turn numbers back into words, which saves memory. |

## Key terms

- **Original model (uncompressed)**: The model exactly as published, with nothing removed or simplified. It is the reference point: the best accuracy we can hope for, and the most memory.
- **Standard quantization**: The compression technique applied the usual way, treating every part of the model the same.
- **Our method**: Our approach: first measure which parts of the model are fragile, then compress the robust parts hard and leave the fragile parts mostly intact.
- **Language model**: A program that has learned from large amounts of text to predict the next word. Chat assistants are built on these. The one used here is described under "Original model".
- **Compression**: Making the model smaller and faster by storing its numbers with less detail or removing some of them, ideally without making its answers worse.
- **Layer**: The model is a stack of similar building blocks called layers; text passes through them one after another.
- **Bits**: Computers store numbers as strings of 0s and 1s (bits). More bits per number keeps more detail but takes more space. The uncompressed model uses 16 bits per number.
- **FP16**: "16-bit floating point", the standard precise format the model is published in.

## Results

All versions were tested under exactly the same conditions (same data, same computer, same settings), so differences come from the method alone. A dash means the measure is not available at this stage.

| Version | Prediction error on test text (validation half) (lower is better) | Prediction error on unseen test text (held-out half) (lower is better) | Short-term memory needed for one long text (GB, lower is better) | Storage used per number in the notes (bits, lower is better) | Share of earlier words the notes keep | Highest graphics-card memory used while running (GB, lower is better) | Time to read the prompt (ms, lower is better) | Time to write each word (ms, lower is better) | Time to prepare the compressed model (s, lower is better) | Real file size of the compressed model (GB, lower is better) | Writing speed (llama.cpp) (tok/s, higher is better) | Prediction error in llama.cpp (validation half) (lower is better) | Real file size of the compressed model (GB, lower is better) | Time per written word-piece (vLLM) (ms, lower is better) | Prediction error in vLLM (validation half) (lower is better) | Size of the built engine (GB, lower is better) | Time per written word-piece (TensorRT-LLM) (ms, lower is better) | Prediction error in TensorRT-LLM (validation half) (lower is better) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Original model (uncompressed) | 10.18 | 10.62 | 0.0461 | 16 | 1 | 2.41 | 5.86 | 4.26 | 0 | 2.2 | 419.33 | 8.12 | 2.2 | 2.54 | 10.18 | 2.21 | 2.69 | 10.18 |
| Standard quantization | 10.25 | 10.69 | 0.013 | 4 | 1 | 2.52 | 7.33 | 5.42 | 0.00109 | – | – | – | – | – | – | – | – | – |
| Our method | 11.68 | 11.99 | 0.00323 | 3.82 | 0.259 | 2.52 | 58.82 | 55.82 | 0.0012 | – | – | – | – | – | – | – | – | – |
| Standard quantization | 10.33 | 10.78 | 0.013 | 4 | 1 | 2.52 | 67.53 | 64.84 | 0.000277 | – | – | – | – | – | – | – | – | – |
| Our method | 11.79 | 12.13 | 0.00323 | 3.82 | 0.259 | 2.52 | 66.85 | 64.95 | 0.000288 | – | – | – | – | – | – | – | – | – |
| Standard quantization | 10.27 | 10.71 | 0.013 | 4 | 1 | 2.52 | 10.39 | 8.08 | 50.89 | – | – | – | – | – | – | – | – | – |
| Our method | 11.75 | 12.07 | 0.00323 | 3.82 | 0.259 | 2.52 | 78.56 | 76.01 | 51.63 | – | – | – | – | – | – | – | – | – |
| Standard quantization | 11.1 | 11.49 | 0.00924 | 16 | 0.2 | 2.52 | 45.29 | 43.17 | 0.000841 | – | – | – | – | – | – | – | – | – |
| Our method | 11.68 | 11.99 | 0.00323 | 3.82 | 0.259 | 2.52 | 59.28 | 56.52 | 0.0012 | – | – | – | – | – | – | – | – | – |
| Standard quantization | 10.57 | 10.99 | 0.00924 | 16 | 0.2 | 2.52 | 45.93 | 43.73 | 0.000865 | – | – | – | – | – | – | – | – | – |
| Our method | 11.36 | 11.73 | 0.00323 | 3.82 | 0.259 | 2.52 | 59.3 | 56.72 | 0.00124 | – | – | – | – | – | – | – | – | – |
| Standard quantization | 11 | 11.41 | 0.00924 | 16 | 0.2 | 2.52 | 45.61 | 43.22 | 0.000866 | – | – | – | – | – | – | – | – | – |
| Our method | 10.38 | 10.8 | 0.00323 | 3.82 | 0.259 | 2.52 | 59.21 | 56.02 | 0.00118 | – | – | – | – | – | – | – | – | – |

**What each column means**

- **Version**: Which version of the model the row describes (see Key terms above).
- **Prediction error on test text (validation half)**: Perplexity measures how well the model predicts the next word of real text it has not been trained on. Think of it as how many words the model is "torn between" at each step: lower means more confident, correct predictions, so a more accurate model. Compression usually raises it a little; a small rise is acceptable, a large rise means the model got noticeably worse at language. The validation half is the part of the test text that is allowed to guide tuning.
- **Prediction error on unseen test text (held-out half)**: Perplexity measures how well the model predicts the next word of real text it has not been trained on. Think of it as how many words the model is "torn between" at each step: lower means more confident, correct predictions, so a more accurate model. Compression usually raises it a little; a small rise is acceptable, a large rise means the model got noticeably worse at language. The held-out half is never used for tuning, so it is the honest check that results were not tuned to one particular piece of text.
- **Short-term memory needed for one long text**: While writing, the model keeps notes on every earlier word (the KV cache). This is how much memory those notes would need for the text length set in the report, calculated from the plan.
- **Storage used per number in the notes**: How many bits each number in the model's notes is stored with, on average (16 uncompressed).
- **Share of earlier words the notes keep**: The plan can let some layers forget earlier words that get almost no attention. 1 means nothing is forgotten; 0.5 means half of the notes are dropped.
- **Highest graphics-card memory used while running**: The most graphics-card memory the model needed at any moment while it was being tested.
- **Time to read the prompt**: How long the model takes to read the user's question before it starts answering, in milliseconds.
- **Time to write each word**: How long the model takes to produce each word (strictly, each word-piece) of its answer, in milliseconds. Lower means faster replies.
- **Time to prepare the compressed model**: How long it took, in seconds, to produce this version of the model. This is a one-off cost paid before the model is used.
- **Real file size of the compressed model**: The size of the model file, in gigabytes. Measured in llama.cpp, the program people use to run models on their own computers, after saving the model in its file format at the plan's bits.
- **Writing speed (llama.cpp)**: How many word-pieces of its answer the model writes per second. Measured in llama.cpp, the program people use to run models on their own computers, after saving the model in its file format at the plan's bits.
- **Prediction error in llama.cpp (validation half)**: Prediction error of the llama.cpp file on the validation half of the test text (lower is better). llama.cpp rounds the numbers its own way and scores only the second half of each window, so compare it between rows, not with the other perplexity columns.
- **Real file size of the compressed model**: The size of the model file, in gigabytes. Measured in vLLM, a program for running models on servers, after saving the model at the plan's bits.
- **Time per written word-piece (vLLM)**: Time to write one word-piece. Measured in vLLM, a program for running models on servers, after saving the model at the plan's bits.
- **Prediction error in vLLM (validation half)**: Prediction error of the saved model on the validation half of the test text (lower is better). The weights are re-rounded when saved, so compare between rows only.
- **Size of the built engine**: The size of the TensorRT engine file, in gigabytes. Measured in TensorRT-LLM, NVIDIA's program for running models fast, after building the model at the plan's bits.
- **Time per written word-piece (TensorRT-LLM)**: Time to write one word-piece. Measured in TensorRT-LLM, NVIDIA's program for running models fast, after building the model at the plan's bits.
- **Prediction error in TensorRT-LLM (validation half)**: Prediction error of the built engine on the validation half of the test text (lower is better). The weights are re-rounded when saved, so compare between rows only.

## Findings

- **Our method** is a trade-off against the standard method: better on some measures, worse on others (better on short-term memory needed for one long text, storage used per number in the notes; worse on prediction error on test text (validation half), time to read the prompt, time to write each word). It costs more to prepare: time to prepare the compressed model (0.000107 s more, paid once).
- **Our method** is a trade-off against the standard method: better on some measures, worse on others (better on short-term memory needed for one long text, storage used per number in the notes; worse on prediction error on test text (validation half)). It costs more to prepare: time to prepare the compressed model (1.05e-05 s more, paid once).
- **Our method** is a trade-off against the standard method: better on some measures, worse on others (better on short-term memory needed for one long text, storage used per number in the notes; worse on prediction error on test text (validation half), time to read the prompt, time to write each word). It costs more to prepare: time to prepare the compressed model (0.746 s more, paid once).
- **Our method** is a trade-off against the standard method: better on some measures, worse on others (better on short-term memory needed for one long text, storage used per number in the notes; worse on prediction error on test text (validation half), time to read the prompt, time to write each word). It costs more to prepare: time to prepare the compressed model (0.000356 s more, paid once).
- **Our method** is a trade-off against the standard method: better on some measures, worse on others (better on short-term memory needed for one long text, storage used per number in the notes; worse on prediction error on test text (validation half), time to read the prompt, time to write each word). It costs more to prepare: time to prepare the compressed model (0.000375 s more, paid once).
- **Our method** is a trade-off against the standard method: better on some measures, worse on others (better on prediction error on test text (validation half), short-term memory needed for one long text, storage used per number in the notes; worse on time to read the prompt, time to write each word). It costs more to prepare: time to prepare the compressed model (0.000314 s more, paid once).
- Some techniques here are simulated: the numbers are rounded as the compressed model would store them, but kept in the uncompressed format. Their accuracy is real; their memory is the plan's prediction, and their speed is not the speed a real compressed model would have.
- Original model (uncompressed) misses a deployment target (target_memory_gb).
- Standard quantization misses a deployment target (target_memory_gb).
- Our method misses a deployment target (target_memory_gb).
- Standard quantization misses a deployment target (target_memory_gb).
- Our method misses a deployment target (target_memory_gb).
- Standard quantization misses a deployment target (target_memory_gb).
- Our method misses a deployment target (target_memory_gb).
- Standard quantization misses a deployment target (target_memory_gb).
- Our method misses a deployment target (target_memory_gb).
- Standard quantization misses a deployment target (target_memory_gb).
- Our method misses a deployment target (target_memory_gb).
- Standard quantization misses a deployment target (target_memory_gb).
- Our method misses a deployment target (target_memory_gb).

## How this stage works

While writing a reply, the model keeps notes on every earlier word (the "KV cache"); for long texts these notes can take more memory than the model itself. This stage stores the notes with fewer bits or forgets the least-used ones. The standard way treats every layer the same; our method follows the Stage 0 plan for each layer.

---

# Technical details

## What was run

- `baseline/fp16`: uncompressed model
- `rtn_kv/original`: Round-to-nearest KV cache, standard settings: uniform plan, KV bits [4], kept share min 1
- `rtn_kv/framework`: Round-to-nearest KV cache, Stage 0 sensitivity plan, KV bits [2, 4], kept share min 0.1
- `quarot_kv/original`: QuaRot KV, standard settings: uniform plan, KV bits [4], kept share min 1
- `quarot_kv/framework`: QuaRot KV, Stage 0 sensitivity plan, KV bits [2, 4], kept share min 0.1
- `kvquant/original`: KVQuant, standard settings: uniform plan, KV bits [4], kept share min 1
- `kvquant/framework`: KVQuant, Stage 0 sensitivity plan, KV bits [2, 4], kept share min 0.1
- `h2o/original`: H2O, standard settings: uniform plan, KV bits [16], kept share min 0.2
- `h2o/framework`: H2O, Stage 0 sensitivity plan, KV bits [2, 4], kept share min 0.1
- `snapkv/original`: SnapKV, standard settings: uniform plan, KV bits [16], kept share min 0.2
- `snapkv/framework`: SnapKV, Stage 0 sensitivity plan, KV bits [2, 4], kept share min 0.1
- `infinigen/original`: InfiniGen, standard settings: uniform plan, KV bits [16], kept share min 0.2
- `infinigen/framework`: InfiniGen, Stage 0 sensitivity plan, KV bits [2, 4], kept share min 0.1

Every row shares these conditions:

- **model**: TinyLlama/TinyLlama-1.1B-Chat-v1.0
- **calibration**: wikitext2, 64 x 512 tokens
- **seed**: 0
- **evaluation data**: wikitext-2 test, 512-token windows, validation/held-out halves
- **device**: cuda
- **backend**: HF Transformers
- **Stage 0 plans**: /content/final_test/results/20261020-colab-a100-final-test/stage_0
- **starting point**: the uncompressed model, for every row (stages are independent)

Original model (from its config):

- **name**: TinyLlama/TinyLlama-1.1B-Chat-v1.0
- **architecture**: LlamaForCausalLM
- **num_parameters**: 1100048384
- **num_layers**: 22
- **hidden_size**: 2048
- **intermediate_size**: 5632
- **num_attention_heads**: 32
- **num_key_value_heads**: 4
- **head_dim**: 64
- **vocab_size**: 32000
- **max_context**: 2048
- **published_dtype**: bfloat16
- **bits_per_parameter**: 16
- **fp16_size_gb**: 2.2
- **tied_embeddings**: no

## Environment

- **python**: 3.13.15
- **platform**: Linux-6.6.122+-x86_64-with-glibc2.39
- **git_commit**: ac990ae
- **git_dirty**: yes
- **torch**: 2.11.0+cu130
- **transformers**: 5.20.1
- **datasets**: 4.8.5
- **numpy**: 2.5.4
- **openpyxl**: 3.1.5
- **optuna**: 5.0.0
- **pymoo**: 0.6.2
- **cuda_available**: yes
- **gpu**: NVIDIA A100-SXM4-80GB
- **gpu_count**: 1
- **cuda**: 13.0

## Results

| Row | Status | Perplexity (validation half) | Perplexity (held-out half) | Predicted KV-cache memory | Average bits per cached number | Share of past tokens kept | Peak GPU memory | Prefill latency (mean) | Decode latency per token (mean) | Build time | llama.cpp file size | llama.cpp decode throughput | llama.cpp perplexity (validation half) | vLLM file size | vLLM decode time per token | vLLM perplexity (validation half) | TensorRT-LLM engine size | TensorRT-LLM decode time per token | TensorRT-LLM perplexity (validation half) | Requirement met |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `baseline/fp16` | ok | 10.18 | 10.62 | 0.04614 | 16 | 1 | 2.414 | 5.858 | 4.258 | 0 | 2.201 | 419.3 | 8.121 | 2.2 | 2.537 | 10.18 | 2.206 | 2.691 | 10.18 | no |
| `rtn_kv/original` | ok | 10.25 | 10.69 | 0.01298 | 4 | 1 | 2.517 | 7.325 | 5.425 | 0.001092 | – | – | – | – | – | – | – | – | – | no |
| `rtn_kv/framework` | ok | 11.68 | 11.99 | 0.003232 | 3.825 | 0.2592 | 2.517 | 58.82 | 55.82 | 0.001199 | – | – | – | – | – | – | – | – | – | no |
| `quarot_kv/original` | ok | 10.33 | 10.78 | 0.01298 | 4 | 1 | 2.517 | 67.53 | 64.84 | 0.0002773 | – | – | – | – | – | – | – | – | – | no |
| `quarot_kv/framework` | ok | 11.79 | 12.13 | 0.003232 | 3.825 | 0.2592 | 2.517 | 66.85 | 64.95 | 0.0002878 | – | – | – | – | – | – | – | – | – | no |
| `kvquant/original` | ok | 10.27 | 10.71 | 0.01298 | 4 | 1 | 2.517 | 10.39 | 8.082 | 50.89 | – | – | – | – | – | – | – | – | – | no |
| `kvquant/framework` | ok | 11.75 | 12.07 | 0.003232 | 3.825 | 0.2592 | 2.517 | 78.56 | 76.01 | 51.63 | – | – | – | – | – | – | – | – | – | no |
| `h2o/original` | ok | 11.1 | 11.49 | 0.009236 | 16 | 0.2002 | 2.517 | 45.29 | 43.17 | 0.0008406 | – | – | – | – | – | – | – | – | – | no |
| `h2o/framework` | ok | 11.68 | 11.99 | 0.003232 | 3.825 | 0.2592 | 2.517 | 59.28 | 56.52 | 0.001197 | – | – | – | – | – | – | – | – | – | no |
| `snapkv/original` | ok | 10.57 | 10.99 | 0.009236 | 16 | 0.2002 | 2.517 | 45.93 | 43.73 | 0.0008653 | – | – | – | – | – | – | – | – | – | no |
| `snapkv/framework` | ok | 11.36 | 11.73 | 0.003232 | 3.825 | 0.2592 | 2.517 | 59.3 | 56.72 | 0.00124 | – | – | – | – | – | – | – | – | – | no |
| `infinigen/original` | ok | 11 | 11.41 | 0.009236 | 16 | 0.2002 | 2.517 | 45.61 | 43.22 | 0.0008655 | – | – | – | – | – | – | – | – | – | no |
| `infinigen/framework` | ok | 10.38 | 10.8 | 0.003232 | 3.825 | 0.2592 | 2.517 | 59.21 | 56.02 | 0.00118 | – | – | – | – | – | – | – | – | – | no |

**What each column means**

- **Row**: Method and version, as `method/variant`: `fp16` is the uncompressed model, `original` the method used the standard way, `framework` the method guided by Stage 0.
- **Status**: `ok` if the row finished, `failed` if it raised an error (the error is under Anomalies).
- **Perplexity (validation half)**: Prediction error on test text (validation half) (lower is better).
- **Perplexity (held-out half)**: Prediction error on unseen test text (held-out half) (lower is better).
- **Predicted KV-cache memory**: Short-term memory needed for one long text (GB, lower is better).
- **Average bits per cached number**: Storage used per number in the notes (bits, lower is better).
- **Share of past tokens kept**: Share of earlier words the notes keep.
- **Peak GPU memory**: Highest graphics-card memory used while running (GB, lower is better).
- **Prefill latency (mean)**: Time to read the prompt (ms, lower is better).
- **Decode latency per token (mean)**: Time to write each word (ms, lower is better).
- **Build time**: Time to prepare the compressed model (s, lower is better).
- **llama.cpp file size**: Real file size of the compressed model (GB, lower is better).
- **llama.cpp decode throughput**: Writing speed (llama.cpp) (tok/s, higher is better).
- **llama.cpp perplexity (validation half)**: Prediction error in llama.cpp (validation half) (lower is better).
- **vLLM file size**: Real file size of the compressed model (GB, lower is better).
- **vLLM decode time per token**: Time per written word-piece (vLLM) (ms, lower is better).
- **vLLM perplexity (validation half)**: Prediction error in vLLM (validation half) (lower is better).
- **TensorRT-LLM engine size**: Size of the built engine (GB, lower is better).
- **TensorRT-LLM decode time per token**: Time per written word-piece (TensorRT-LLM) (ms, lower is better).
- **TensorRT-LLM perplexity (validation half)**: Prediction error in TensorRT-LLM (validation half) (lower is better).
- **Requirement met**: Whether the row meets every deployment target that was set; `no targets set` when the run set none, `n/a` when a target cannot be measured at this stage.

Full metrics, deltas and raw measurements are in `stage_3_comparison.xlsx` and `results.json`.

## Key findings

- **rtn_kv**: the framework trades off against the original method. Better on Predicted KV-cache memory (-0.009744, -75.1%); Average bits per cached number (-0.1754, -4.4%). Worse on Perplexity (validation half) (+1.428, +13.9%); Prefill latency (mean) (+51.49, +703.0%); Decode latency per token (mean) (+50.39, +929.0%). One-off cost: Build time (+0.0001072, +9.8%).
- **quarot_kv**: the framework trades off against the original method. Better on Predicted KV-cache memory (-0.009744, -75.1%); Average bits per cached number (-0.1754, -4.4%). Worse on Perplexity (validation half) (+1.462, +14.2%). One-off cost: Build time (+1.05e-05, +3.8%).
- **kvquant**: the framework trades off against the original method. Better on Predicted KV-cache memory (-0.009744, -75.1%); Average bits per cached number (-0.1754, -4.4%). Worse on Perplexity (validation half) (+1.483, +14.4%); Prefill latency (mean) (+68.17, +655.8%); Decode latency per token (mean) (+67.93, +840.5%). One-off cost: Build time (+0.7455, +1.5%).
- **h2o**: the framework trades off against the original method. Better on Predicted KV-cache memory (-0.006004, -65.0%); Average bits per cached number (-12.18, -76.1%). Worse on Perplexity (validation half) (+0.5779, +5.2%); Prefill latency (mean) (+13.99, +30.9%); Decode latency per token (mean) (+13.35, +30.9%). One-off cost: Build time (+0.0003562, +42.4%).
- **snapkv**: the framework trades off against the original method. Better on Predicted KV-cache memory (-0.006004, -65.0%); Average bits per cached number (-12.18, -76.1%). Worse on Perplexity (validation half) (+0.7912, +7.5%); Prefill latency (mean) (+13.37, +29.1%); Decode latency per token (mean) (+12.99, +29.7%). One-off cost: Build time (+0.0003745, +43.3%).
- **infinigen**: the framework trades off against the original method. Better on Perplexity (validation half) (-0.6172, -5.6%); Predicted KV-cache memory (-0.006004, -65.0%); Average bits per cached number (-12.18, -76.1%). Worse on Prefill latency (mean) (+13.59, +29.8%); Decode latency per token (mean) (+12.8, +29.6%). One-off cost: Build time (+0.0003144, +36.3%).
- baseline/fp16 misses the deployment requirement: target_memory_gb over by 1.1.
- rtn_kv/original misses the deployment requirement: target_memory_gb over by 1.1.
- rtn_kv/framework misses the deployment requirement: target_memory_gb over by 1.1.
- quarot_kv/original misses the deployment requirement: target_memory_gb over by 1.1.
- quarot_kv/framework misses the deployment requirement: target_memory_gb over by 1.1.
- kvquant/original misses the deployment requirement: target_memory_gb over by 1.1.
- kvquant/framework misses the deployment requirement: target_memory_gb over by 1.1.
- h2o/original misses the deployment requirement: target_memory_gb over by 1.1.
- h2o/framework misses the deployment requirement: target_memory_gb over by 1.1.
- snapkv/original misses the deployment requirement: target_memory_gb over by 1.1.
- snapkv/framework misses the deployment requirement: target_memory_gb over by 1.1.
- infinigen/original misses the deployment requirement: target_memory_gb over by 1.1.
- infinigen/framework misses the deployment requirement: target_memory_gb over by 1.1.

## Anomalies and failures

- None.

## Suggested next steps

- None.
