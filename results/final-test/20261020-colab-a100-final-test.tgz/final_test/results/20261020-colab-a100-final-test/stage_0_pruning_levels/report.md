# Stage 0: Pruning levels test (for Stage 2)

Run started 2026-10-21 05:10:36.

## Summary

This report has no standard-versus-our-method comparison; the results are in the tables below.

## Original model

Every version in this report starts from this model, unchanged as published.

| What | Value | What it means |
|---|---|---|
| Model | TinyLlama/TinyLlama-1.1B-Chat-v1.0 | The published model every result in this report starts from. |
| Architecture | LlamaForCausalLM | The model family's design; models of the same family are built the same way. |
| Parameters | 1,100,048,384 (1.10 billion) | How many numbers the model has learned. More numbers usually means a more capable but bigger and slower model. |
| Layers | 22 | How many similar building blocks the text passes through, one after another. Stage 0 measures each one separately. |
| Hidden size | 2,048 | How many numbers describe each word inside the model, as it passes from layer to layer. |
| Feed-forward size | 5,632 | How wide the "thinking" part inside each layer is, in numbers per word. |
| Attention heads | 32 | How many separate ways each layer looks back at earlier words at the same time. |
| Key/value heads | 4 | How many sets of notes each layer stores about earlier words (the KV cache). Fewer than the attention heads means the notes are shared, which saves memory. |
| Numbers per head | 64 | How many numbers each attention head uses per word. |
| Vocabulary | 32,000 | How many different word pieces (tokens) the model knows. |
| Maximum context | 2,048 tokens | The most tokens (word pieces) the model can read and write at once. |
| Published number format | bfloat16 | How the numbers are stored in the published model files. |
| Bits per number | 16 bits | Storage per number in the uncompressed model; compression lowers this. |
| Size at 16 bits | 2.20 GB | Memory the numbers take in the uncompressed 16-bit format (parameters x 2 bytes). |
| Input and output word tables shared | no | Whether the table turning words into numbers is reused to turn numbers back into words, which saves memory. |

## Key terms

- **Original model (uncompressed)**: The model exactly as published, with nothing removed or simplified. It is the reference point: the best accuracy we can hope for, and the most memory.
- **Language model**: A program that has learned from large amounts of text to predict the next word. Chat assistants are built on these. The one used here is described under "Original model".
- **Compression**: Making the model smaller and faster by storing its numbers with less detail or removing some of them, ideally without making its answers worse.
- **Layer**: The model is a stack of similar building blocks called layers; text passes through them one after another.
- **Bits**: Computers store numbers as strings of 0s and 1s (bits). More bits per number keeps more detail but takes more space. The uncompressed model uses 16 bits per number.
- **FP16**: "16-bit floating point", the standard precise format the model is published in.

## Results

All versions were tested under exactly the same conditions (same data, same computer, same settings), so differences come from the method alone. A dash means the measure is not available at this stage.

| Version | Prediction error on test text (validation half) (lower is better) | Prediction error on unseen test text (held-out half) (lower is better) | Share of the decoder layers' weights removed |
|---|---|---|---|
| Original model (uncompressed) | 10.18 | 10.62 | 0 |
| Wanda (single weights), all layers, 30% | 10.66 | 11.11 | 0.3 |
| Wanda (single weights), all layers, 40% | 11.54 | 11.97 | 0.4 |
| Wanda (single weights), all layers, 50% | 14.11 | 14.52 | 0.5 |
| Wanda (single weights), all layers, 60% | 26.07 | 26.72 | 0.6 |
| Wanda (single weights), all layers, 70% | 92.51 | 98.41 | 0.7 |
| Wanda (single weights), all layers, 80% | 654.71 | 673.11 | 0.8 |
| Wanda (single weights), all layers, 90% | 5,682 | 5,699 | 0.9 |
| Wanda (single weights), non-guarded layers, 30% | 10.52 | 10.97 | 0.232 |
| Wanda (single weights), non-guarded layers, 40% | 11.15 | 11.58 | 0.309 |
| Wanda (single weights), non-guarded layers, 50% | 13.09 | 13.48 | 0.386 |
| Wanda (single weights), non-guarded layers, 60% | 21.04 | 21.57 | 0.464 |
| Wanda (single weights), non-guarded layers, 70% | 56.46 | 58.91 | 0.541 |
| Wanda (single weights), non-guarded layers, 80% | 213.67 | 214.48 | 0.618 |
| Wanda (single weights), non-guarded layers, 90% | 1,968 | 1,936 | 0.695 |
| Wanda (single weights), guarded layers only, 30% | 10.31 | 10.75 | 0.0682 |
| Wanda (single weights), guarded layers only, 40% | 10.54 | 10.98 | 0.0909 |
| Wanda (single weights), guarded layers only, 50% | 10.94 | 11.36 | 0.114 |
| Wanda (single weights), guarded layers only, 60% | 11.96 | 12.35 | 0.136 |
| Wanda (single weights), guarded layers only, 70% | 14.55 | 14.99 | 0.159 |
| Wanda (single weights), guarded layers only, 80% | 22.54 | 22.75 | 0.182 |
| Wanda (single weights), guarded layers only, 90% | 447.75 | 369.66 | 0.205 |
| Structured (feed-forward channels), all layers, 30% | 17.5 | 18.13 | 0.3 |
| Structured (feed-forward channels), all layers, 40% | 26.72 | 27.42 | 0.4 |
| Structured (feed-forward channels), all layers, 50% | 48.37 | 49.39 | 0.5 |
| Structured (feed-forward channels), all layers, 60% | 111.92 | 114.59 | 0.6 |
| Structured (feed-forward channels), all layers, 70% | 1,156 | 896.48 | 0.7 |
| Structured (feed-forward channels), all layers, 75.0% (capped from 80%) | 19,765 | 19,172 | 0.75 |
| Structured (feed-forward channels), all layers, 75.0% (capped from 90%) | 19,765 | 19,172 | 0.75 |
| Structured (feed-forward channels), non-guarded layers, 30% | 14.58 | 15.07 | 0.232 |
| Structured (feed-forward channels), non-guarded layers, 40% | 19.75 | 19.95 | 0.309 |
| Structured (feed-forward channels), non-guarded layers, 50% | 32.97 | 31.95 | 0.386 |
| Structured (feed-forward channels), non-guarded layers, 60% | 69.7 | 65.6 | 0.464 |
| Structured (feed-forward channels), non-guarded layers, 70% | 258.01 | 225.23 | 0.541 |
| Structured (feed-forward channels), non-guarded layers, 75.0% (capped from 80%) | 2,431 | 1,962 | 0.58 |
| Structured (feed-forward channels), non-guarded layers, 75.0% (capped from 90%) | 2,431 | 1,962 | 0.58 |
| Structured (feed-forward channels), guarded layers only, 30% | 11.64 | 12.2 | 0.0682 |
| Structured (feed-forward channels), guarded layers only, 40% | 12.63 | 13.2 | 0.0909 |
| Structured (feed-forward channels), guarded layers only, 50% | 14.32 | 14.96 | 0.114 |
| Structured (feed-forward channels), guarded layers only, 60% | 16.78 | 17.4 | 0.136 |
| Structured (feed-forward channels), guarded layers only, 70% | 22.97 | 22.56 | 0.159 |
| Structured (feed-forward channels), guarded layers only, 75.0% (capped from 80%) | 52.83 | 52.3 | 0.17 |
| Structured (feed-forward channels), guarded layers only, 75.0% (capped from 90%) | 52.83 | 52.3 | 0.17 |
| Low-rank (activation-aware SVD), all layers, 30% | 163.57 | 175.5 | 0.3 |
| Low-rank (activation-aware SVD), all layers, 40% | 424.5 | 432.53 | 0.4 |
| Low-rank (activation-aware SVD), all layers, 50% | 1,174 | 1,161 | 0.5 |
| Low-rank (activation-aware SVD), all layers, 60% | 6,635 | 6,270 | 0.6 |
| Low-rank (activation-aware SVD), all layers, 70% | 11,529 | 11,484 | 0.7 |
| Low-rank (activation-aware SVD), all layers, 80% | 21,881 | 20,617 | 0.8 |
| Low-rank (activation-aware SVD), all layers, 90% | 5,677 | 5,391 | 0.9 |
| Low-rank (activation-aware SVD), non-guarded layers, 30% | 67.92 | 69.15 | 0.232 |
| Low-rank (activation-aware SVD), non-guarded layers, 40% | 159.16 | 163.19 | 0.309 |
| Low-rank (activation-aware SVD), non-guarded layers, 50% | 384.83 | 386.62 | 0.386 |
| Low-rank (activation-aware SVD), non-guarded layers, 60% | 1,315 | 1,294 | 0.464 |
| Low-rank (activation-aware SVD), non-guarded layers, 70% | 3,760 | 3,739 | 0.541 |
| Low-rank (activation-aware SVD), non-guarded layers, 80% | 5,340 | 5,223 | 0.618 |
| Low-rank (activation-aware SVD), non-guarded layers, 90% | 5,739 | 5,285 | 0.695 |
| Low-rank (activation-aware SVD), guarded layers only, 30% | 14.69 | 15.31 | 0.0682 |
| Low-rank (activation-aware SVD), guarded layers only, 40% | 16.17 | 16.75 | 0.0909 |
| Low-rank (activation-aware SVD), guarded layers only, 50% | 18.55 | 19.07 | 0.114 |
| Low-rank (activation-aware SVD), guarded layers only, 60% | 22.23 | 22.56 | 0.136 |
| Low-rank (activation-aware SVD), guarded layers only, 70% | 29.08 | 29.25 | 0.159 |
| Low-rank (activation-aware SVD), guarded layers only, 80% | 45.99 | 45.27 | 0.182 |
| Low-rank (activation-aware SVD), guarded layers only, 90% | 156.66 | 160.19 | 0.205 |

**What each column means**

- **Version**: Which version of the model the row describes (see Key terms above).
- **Prediction error on test text (validation half)**: Perplexity measures how well the model predicts the next word of real text it has not been trained on. Think of it as how many words the model is "torn between" at each step: lower means more confident, correct predictions, so a more accurate model. Compression usually raises it a little; a small rise is acceptable, a large rise means the model got noticeably worse at language. The validation half is the part of the test text that is allowed to guide tuning.
- **Prediction error on unseen test text (held-out half)**: Perplexity measures how well the model predicts the next word of real text it has not been trained on. Think of it as how many words the model is "torn between" at each step: lower means more confident, correct predictions, so a more accurate model. Compression usually raises it a little; a small rise is acceptable, a large rise means the model got noticeably worse at language. The held-out half is never used for tuning, so it is the honest check that results were not tuned to one particular piece of text.
- **Share of the decoder layers' weights removed**: Pruning deletes numbers that matter least. This is the share of the decoder layers' weights (the Linear weights of the repeated layers; embeddings, output head and norms are not counted) that the row deletes (0.1 means 10%).

## Findings


---

# Technical details

## What was run

- `baseline/fp16`: uncompressed model (Stage 0 measurement)
- `wanda_all_layers_030/original`: Wanda (single weights) removes 30% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `wanda_all_layers_040/original`: Wanda (single weights) removes 40% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `wanda_all_layers_050/original`: Wanda (single weights) removes 50% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `wanda_all_layers_060/original`: Wanda (single weights) removes 60% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `wanda_all_layers_070/original`: Wanda (single weights) removes 70% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `wanda_all_layers_080/original`: Wanda (single weights) removes 80% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `wanda_all_layers_090/original`: Wanda (single weights) removes 90% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `wanda_non_guarded_layers_030/original`: Wanda (single weights) removes 30% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `wanda_non_guarded_layers_040/original`: Wanda (single weights) removes 40% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `wanda_non_guarded_layers_050/original`: Wanda (single weights) removes 50% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `wanda_non_guarded_layers_060/original`: Wanda (single weights) removes 60% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `wanda_non_guarded_layers_070/original`: Wanda (single weights) removes 70% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `wanda_non_guarded_layers_080/original`: Wanda (single weights) removes 80% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `wanda_non_guarded_layers_090/original`: Wanda (single weights) removes 90% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `wanda_guarded_layers_only_030/original`: Wanda (single weights) removes 30% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `wanda_guarded_layers_only_040/original`: Wanda (single weights) removes 40% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `wanda_guarded_layers_only_050/original`: Wanda (single weights) removes 50% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `wanda_guarded_layers_only_060/original`: Wanda (single weights) removes 60% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `wanda_guarded_layers_only_070/original`: Wanda (single weights) removes 70% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `wanda_guarded_layers_only_080/original`: Wanda (single weights) removes 80% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `wanda_guarded_layers_only_090/original`: Wanda (single weights) removes 90% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `structured_all_layers_030/original`: Structured (feed-forward channels) removes 30% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `structured_all_layers_040/original`: Structured (feed-forward channels) removes 40% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `structured_all_layers_050/original`: Structured (feed-forward channels) removes 50% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `structured_all_layers_060/original`: Structured (feed-forward channels) removes 60% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `structured_all_layers_070/original`: Structured (feed-forward channels) removes 70% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `structured_all_layers_080/original`: Structured (feed-forward channels) removes 75.0% (capped from 80%) of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `structured_all_layers_090/original`: Structured (feed-forward channels) removes 75.0% (capped from 90%) of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `structured_non_guarded_layers_030/original`: Structured (feed-forward channels) removes 30% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `structured_non_guarded_layers_040/original`: Structured (feed-forward channels) removes 40% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `structured_non_guarded_layers_050/original`: Structured (feed-forward channels) removes 50% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `structured_non_guarded_layers_060/original`: Structured (feed-forward channels) removes 60% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `structured_non_guarded_layers_070/original`: Structured (feed-forward channels) removes 70% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `structured_non_guarded_layers_080/original`: Structured (feed-forward channels) removes 75.0% (capped from 80%) of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `structured_non_guarded_layers_090/original`: Structured (feed-forward channels) removes 75.0% (capped from 90%) of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `structured_guarded_layers_only_030/original`: Structured (feed-forward channels) removes 30% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `structured_guarded_layers_only_040/original`: Structured (feed-forward channels) removes 40% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `structured_guarded_layers_only_050/original`: Structured (feed-forward channels) removes 50% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `structured_guarded_layers_only_060/original`: Structured (feed-forward channels) removes 60% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `structured_guarded_layers_only_070/original`: Structured (feed-forward channels) removes 70% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `structured_guarded_layers_only_080/original`: Structured (feed-forward channels) removes 75.0% (capped from 80%) of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `structured_guarded_layers_only_090/original`: Structured (feed-forward channels) removes 75.0% (capped from 90%) of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `low_rank_all_layers_030/original`: Low-rank (activation-aware SVD) removes 30% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `low_rank_all_layers_040/original`: Low-rank (activation-aware SVD) removes 40% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `low_rank_all_layers_050/original`: Low-rank (activation-aware SVD) removes 50% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `low_rank_all_layers_060/original`: Low-rank (activation-aware SVD) removes 60% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `low_rank_all_layers_070/original`: Low-rank (activation-aware SVD) removes 70% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `low_rank_all_layers_080/original`: Low-rank (activation-aware SVD) removes 80% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `low_rank_all_layers_090/original`: Low-rank (activation-aware SVD) removes 90% of each of layers [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21] (pruning only, nothing rounded)
- `low_rank_non_guarded_layers_030/original`: Low-rank (activation-aware SVD) removes 30% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `low_rank_non_guarded_layers_040/original`: Low-rank (activation-aware SVD) removes 40% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `low_rank_non_guarded_layers_050/original`: Low-rank (activation-aware SVD) removes 50% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `low_rank_non_guarded_layers_060/original`: Low-rank (activation-aware SVD) removes 60% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `low_rank_non_guarded_layers_070/original`: Low-rank (activation-aware SVD) removes 70% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `low_rank_non_guarded_layers_080/original`: Low-rank (activation-aware SVD) removes 80% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `low_rank_non_guarded_layers_090/original`: Low-rank (activation-aware SVD) removes 90% of each of layers [3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] (pruning only, nothing rounded)
- `low_rank_guarded_layers_only_030/original`: Low-rank (activation-aware SVD) removes 30% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `low_rank_guarded_layers_only_040/original`: Low-rank (activation-aware SVD) removes 40% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `low_rank_guarded_layers_only_050/original`: Low-rank (activation-aware SVD) removes 50% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `low_rank_guarded_layers_only_060/original`: Low-rank (activation-aware SVD) removes 60% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `low_rank_guarded_layers_only_070/original`: Low-rank (activation-aware SVD) removes 70% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `low_rank_guarded_layers_only_080/original`: Low-rank (activation-aware SVD) removes 80% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)
- `low_rank_guarded_layers_only_090/original`: Low-rank (activation-aware SVD) removes 90% of each of layers [0, 1, 2, 7, 21] (pruning only, nothing rounded)

Every row shares these conditions:

- **model**: TinyLlama/TinyLlama-1.1B-Chat-v1.0
- **seed**: 0
- **device**: cuda
- **calibration**: wikitext2, 64 x 512 tokens
- **levels**: 30%, 40%, 50%, 60%, 70%, 80%, 90%
- **guarded layers**: [0, 1, 2, 7, 21]
- **layer sets**: all_layers, non_guarded_layers, guarded_layers_only
- **rounding**: none (pruning only)

Original model (from its config):

- **name**: TinyLlama/TinyLlama-1.1B-Chat-v1.0
- **architecture**: LlamaForCausalLM
- **num_parameters**: 1100048384
- **num_layers**: 22
- **hidden_size**: 2048
- **intermediate_size**: 5632
- **num_attention_heads**: 32
- **num_key_value_heads**: 4
- **head_dim**: 64
- **vocab_size**: 32000
- **max_context**: 2048
- **published_dtype**: bfloat16
- **bits_per_parameter**: 16
- **fp16_size_gb**: 2.2
- **tied_embeddings**: no

## Environment

- **python**: 3.13.15
- **platform**: Linux-6.6.122+-x86_64-with-glibc2.39
- **git_commit**: ac990ae
- **git_dirty**: no
- **torch**: 2.11.0+cu130
- **transformers**: 5.20.1
- **datasets**: 4.8.5
- **numpy**: 2.5.4
- **openpyxl**: 3.1.5
- **optuna**: 5.0.0
- **pymoo**: 0.6.2
- **cuda_available**: yes
- **gpu**: NVIDIA A100-SXM4-80GB
- **gpu_count**: 1
- **cuda**: 13.0

## Results

| Row | Status | Perplexity (validation half) | Perplexity (held-out half) | Share of the decoder layers' weights removed | Requirement met |
|---|---|---|---|---|---|
| `baseline/fp16` | ok | 10.18 | 10.62 | 0 | n/a (not all targets measurable yet) |
| `wanda_all_layers_030/original` | ok | 10.66 | 11.11 | 0.3 | n/a (not all targets measurable yet) |
| `wanda_all_layers_040/original` | ok | 11.54 | 11.97 | 0.4 | n/a (not all targets measurable yet) |
| `wanda_all_layers_050/original` | ok | 14.11 | 14.52 | 0.5 | n/a (not all targets measurable yet) |
| `wanda_all_layers_060/original` | ok | 26.07 | 26.72 | 0.6 | n/a (not all targets measurable yet) |
| `wanda_all_layers_070/original` | ok | 92.51 | 98.41 | 0.7 | n/a (not all targets measurable yet) |
| `wanda_all_layers_080/original` | ok | 654.7 | 673.1 | 0.8 | n/a (not all targets measurable yet) |
| `wanda_all_layers_090/original` | ok | 5682 | 5699 | 0.9 | n/a (not all targets measurable yet) |
| `wanda_non_guarded_layers_030/original` | ok | 10.52 | 10.97 | 0.2318 | n/a (not all targets measurable yet) |
| `wanda_non_guarded_layers_040/original` | ok | 11.15 | 11.58 | 0.3091 | n/a (not all targets measurable yet) |
| `wanda_non_guarded_layers_050/original` | ok | 13.09 | 13.48 | 0.3864 | n/a (not all targets measurable yet) |
| `wanda_non_guarded_layers_060/original` | ok | 21.04 | 21.57 | 0.4636 | n/a (not all targets measurable yet) |
| `wanda_non_guarded_layers_070/original` | ok | 56.46 | 58.91 | 0.5409 | n/a (not all targets measurable yet) |
| `wanda_non_guarded_layers_080/original` | ok | 213.7 | 214.5 | 0.6182 | n/a (not all targets measurable yet) |
| `wanda_non_guarded_layers_090/original` | ok | 1968 | 1936 | 0.6955 | n/a (not all targets measurable yet) |
| `wanda_guarded_layers_only_030/original` | ok | 10.31 | 10.75 | 0.06818 | n/a (not all targets measurable yet) |
| `wanda_guarded_layers_only_040/original` | ok | 10.54 | 10.98 | 0.09091 | n/a (not all targets measurable yet) |
| `wanda_guarded_layers_only_050/original` | ok | 10.94 | 11.36 | 0.1136 | n/a (not all targets measurable yet) |
| `wanda_guarded_layers_only_060/original` | ok | 11.96 | 12.35 | 0.1364 | n/a (not all targets measurable yet) |
| `wanda_guarded_layers_only_070/original` | ok | 14.55 | 14.99 | 0.1591 | n/a (not all targets measurable yet) |
| `wanda_guarded_layers_only_080/original` | ok | 22.54 | 22.75 | 0.1818 | n/a (not all targets measurable yet) |
| `wanda_guarded_layers_only_090/original` | ok | 447.7 | 369.7 | 0.2045 | n/a (not all targets measurable yet) |
| `structured_all_layers_030/original` | ok | 17.5 | 18.13 | 0.3 | n/a (not all targets measurable yet) |
| `structured_all_layers_040/original` | ok | 26.72 | 27.42 | 0.4 | n/a (not all targets measurable yet) |
| `structured_all_layers_050/original` | ok | 48.37 | 49.39 | 0.5 | n/a (not all targets measurable yet) |
| `structured_all_layers_060/original` | ok | 111.9 | 114.6 | 0.6 | n/a (not all targets measurable yet) |
| `structured_all_layers_070/original` | ok | 1156 | 896.5 | 0.7 | n/a (not all targets measurable yet) |
| `structured_all_layers_080/original` | ok | 1.976e+04 | 1.917e+04 | 0.75 | n/a (not all targets measurable yet) |
| `structured_all_layers_090/original` | ok | 1.976e+04 | 1.917e+04 | 0.75 | n/a (not all targets measurable yet) |
| `structured_non_guarded_layers_030/original` | ok | 14.58 | 15.07 | 0.2318 | n/a (not all targets measurable yet) |
| `structured_non_guarded_layers_040/original` | ok | 19.75 | 19.95 | 0.3091 | n/a (not all targets measurable yet) |
| `structured_non_guarded_layers_050/original` | ok | 32.97 | 31.95 | 0.3864 | n/a (not all targets measurable yet) |
| `structured_non_guarded_layers_060/original` | ok | 69.7 | 65.6 | 0.4636 | n/a (not all targets measurable yet) |
| `structured_non_guarded_layers_070/original` | ok | 258 | 225.2 | 0.5409 | n/a (not all targets measurable yet) |
| `structured_non_guarded_layers_080/original` | ok | 2431 | 1962 | 0.5795 | n/a (not all targets measurable yet) |
| `structured_non_guarded_layers_090/original` | ok | 2431 | 1962 | 0.5795 | n/a (not all targets measurable yet) |
| `structured_guarded_layers_only_030/original` | ok | 11.64 | 12.2 | 0.06818 | n/a (not all targets measurable yet) |
| `structured_guarded_layers_only_040/original` | ok | 12.63 | 13.2 | 0.09091 | n/a (not all targets measurable yet) |
| `structured_guarded_layers_only_050/original` | ok | 14.32 | 14.96 | 0.1136 | n/a (not all targets measurable yet) |
| `structured_guarded_layers_only_060/original` | ok | 16.78 | 17.4 | 0.1364 | n/a (not all targets measurable yet) |
| `structured_guarded_layers_only_070/original` | ok | 22.97 | 22.56 | 0.1591 | n/a (not all targets measurable yet) |
| `structured_guarded_layers_only_080/original` | ok | 52.83 | 52.3 | 0.1705 | n/a (not all targets measurable yet) |
| `structured_guarded_layers_only_090/original` | ok | 52.83 | 52.3 | 0.1705 | n/a (not all targets measurable yet) |
| `low_rank_all_layers_030/original` | ok | 163.6 | 175.5 | 0.3 | n/a (not all targets measurable yet) |
| `low_rank_all_layers_040/original` | ok | 424.5 | 432.5 | 0.4 | n/a (not all targets measurable yet) |
| `low_rank_all_layers_050/original` | ok | 1174 | 1161 | 0.5 | n/a (not all targets measurable yet) |
| `low_rank_all_layers_060/original` | ok | 6635 | 6270 | 0.6 | n/a (not all targets measurable yet) |
| `low_rank_all_layers_070/original` | ok | 1.153e+04 | 1.148e+04 | 0.7 | n/a (not all targets measurable yet) |
| `low_rank_all_layers_080/original` | ok | 2.188e+04 | 2.062e+04 | 0.8 | n/a (not all targets measurable yet) |
| `low_rank_all_layers_090/original` | ok | 5677 | 5391 | 0.9 | n/a (not all targets measurable yet) |
| `low_rank_non_guarded_layers_030/original` | ok | 67.92 | 69.15 | 0.2318 | n/a (not all targets measurable yet) |
| `low_rank_non_guarded_layers_040/original` | ok | 159.2 | 163.2 | 0.3091 | n/a (not all targets measurable yet) |
| `low_rank_non_guarded_layers_050/original` | ok | 384.8 | 386.6 | 0.3864 | n/a (not all targets measurable yet) |
| `low_rank_non_guarded_layers_060/original` | ok | 1315 | 1294 | 0.4636 | n/a (not all targets measurable yet) |
| `low_rank_non_guarded_layers_070/original` | ok | 3760 | 3739 | 0.5409 | n/a (not all targets measurable yet) |
| `low_rank_non_guarded_layers_080/original` | ok | 5340 | 5223 | 0.6182 | n/a (not all targets measurable yet) |
| `low_rank_non_guarded_layers_090/original` | ok | 5739 | 5285 | 0.6955 | n/a (not all targets measurable yet) |
| `low_rank_guarded_layers_only_030/original` | ok | 14.69 | 15.31 | 0.06818 | n/a (not all targets measurable yet) |
| `low_rank_guarded_layers_only_040/original` | ok | 16.17 | 16.75 | 0.09091 | n/a (not all targets measurable yet) |
| `low_rank_guarded_layers_only_050/original` | ok | 18.55 | 19.07 | 0.1136 | n/a (not all targets measurable yet) |
| `low_rank_guarded_layers_only_060/original` | ok | 22.23 | 22.56 | 0.1364 | n/a (not all targets measurable yet) |
| `low_rank_guarded_layers_only_070/original` | ok | 29.08 | 29.25 | 0.1591 | n/a (not all targets measurable yet) |
| `low_rank_guarded_layers_only_080/original` | ok | 45.99 | 45.27 | 0.1818 | n/a (not all targets measurable yet) |
| `low_rank_guarded_layers_only_090/original` | ok | 156.7 | 160.2 | 0.2045 | n/a (not all targets measurable yet) |

**What each column means**

- **Row**: Method and version, as `method/variant`: `fp16` is the uncompressed model, `original` the method used the standard way, `framework` the method guided by Stage 0.
- **Status**: `ok` if the row finished, `failed` if it raised an error (the error is under Anomalies).
- **Perplexity (validation half)**: Prediction error on test text (validation half) (lower is better).
- **Perplexity (held-out half)**: Prediction error on unseen test text (held-out half) (lower is better).
- **Share of the decoder layers' weights removed**: Share of the decoder layers' weights removed.
- **Requirement met**: Whether the row meets every deployment target that was set; `no targets set` when the run set none, `n/a` when a target cannot be measured at this stage.

Full metrics, deltas and raw measurements are in `stage_0_comparison.xlsx` and `results.json`.

## Key findings

- No findings.

## Perplexity by technique, layer set and level

| Technique | Layers pruned | 30% | 40% | 50% | 60% | 70% | 80% | 90% |
|---|---|---|---|---|---|---|---|---|
| Wanda (single weights) | All layers (22) | 10.66 | 11.54 | 14.11 | 26.07 | 92.51 | 654.7 | 5682 |
| Wanda (single weights) | Non-guarded layers (17) | 10.52 | 11.15 | 13.09 | 21.04 | 56.46 | 213.7 | 1968 |
| Wanda (single weights) | Guarded layers only (5) | 10.31 | 10.54 | 10.94 | 11.96 | 14.55 | 22.54 | 447.7 |
| Structured (feed-forward channels) | All layers (22) | 17.5 | 26.72 | 48.37 | 111.9 | 1156 | 1.976e+04 (capped 75.0%) | 1.976e+04 (capped 75.0%) |
| Structured (feed-forward channels) | Non-guarded layers (17) | 14.58 | 19.75 | 32.97 | 69.7 | 258 | 2431 (capped 75.0%) | 2431 (capped 75.0%) |
| Structured (feed-forward channels) | Guarded layers only (5) | 11.64 | 12.63 | 14.32 | 16.78 | 22.97 | 52.83 (capped 75.0%) | 52.83 (capped 75.0%) |
| Low-rank (activation-aware SVD) | All layers (22) | 163.6 | 424.5 | 1174 | 6635 | 1.153e+04 | 2.188e+04 | 5677 |
| Low-rank (activation-aware SVD) | Non-guarded layers (17) | 67.92 | 159.2 | 384.8 | 1315 | 3760 | 5340 | 5739 |
| Low-rank (activation-aware SVD) | Guarded layers only (5) | 14.69 | 16.17 | 18.55 | 22.23 | 29.08 | 45.99 | 156.7 |

**What each column means**

- **Level**: the share of weights removed from each pruned layer. Nothing is rounded.
- **Cells**: perplexity on the validation half of the test text; lower is better (uncompressed model: 10.18).
- **Guarded layers**: [0, 1, 2, 7, 21] (never pruned by Our method).
- **Capped**: structured pruning removes at most 75% of a layer, or the layer's feed-forward share when that is lower (it removes only feed-forward channels), as in Stage 2; the cell shows the share really removed.
- **Low-rank**: the share removed is the share of numbers the two smaller factors save; the factors are multiplied back into a full-size matrix here, so the weights are not zeros.
- Every value, with the held-out half and the share of the decoder layers' weights removed, is in pruning_levels.csv.

## Anomalies and failures

- None.

## Suggested next steps

- None.
