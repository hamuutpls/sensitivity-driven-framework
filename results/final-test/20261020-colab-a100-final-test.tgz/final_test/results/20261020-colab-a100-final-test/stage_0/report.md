# Stage 0: Sensitivity profiling and compression planning

Run started 2026-10-21 05:09:12.

## Summary

Stage 0 measured how sensitive each of the model's 22 layers is, using 64 short passages of ordinary text, and planned how to compress it. The sensitivity-guided plan protects the 11 most sensitive layers and compresses the other 11. It is predicted to need 1.00 GB, against 0.78 GB for the standard method (every layer at 4 bits) and 2.20 GB for the uncompressed model. Layers 0, 1, 2, 7, 21 behave unusually and should be checked. For the short-term memory (KV cache) of a 2048-token text, the plan predicts 0.00323 GB against 0.013 GB for standard 4-bit notes and 0.0461 GB uncompressed. Nothing has been compressed yet: the real accuracy and speed of these plans are measured in Stage 1.

## Original model

Every version in this report starts from this model, unchanged as published.

| What | Value | What it means |
|---|---|---|
| Model | TinyLlama/TinyLlama-1.1B-Chat-v1.0 | The published model every result in this report starts from. |
| Architecture | LlamaForCausalLM | The model family's design; models of the same family are built the same way. |
| Parameters | 1,100,048,384 (1.10 billion) | How many numbers the model has learned. More numbers usually means a more capable but bigger and slower model. |
| Layers | 22 | How many similar building blocks the text passes through, one after another. Stage 0 measures each one separately. |
| Hidden size | 2,048 | How many numbers describe each word inside the model, as it passes from layer to layer. |
| Feed-forward size | 5,632 | How wide the "thinking" part inside each layer is, in numbers per word. |
| Attention heads | 32 | How many separate ways each layer looks back at earlier words at the same time. |
| Key/value heads | 4 | How many sets of notes each layer stores about earlier words (the KV cache). Fewer than the attention heads means the notes are shared, which saves memory. |
| Numbers per head | 64 | How many numbers each attention head uses per word. |
| Vocabulary | 32,000 | How many different word pieces (tokens) the model knows. |
| Maximum context | 2,048 tokens | The most tokens (word pieces) the model can read and write at once. |
| Published number format | bfloat16 | How the numbers are stored in the published model files. |
| Bits per number | 16 bits | Storage per number in the uncompressed model; compression lowers this. |
| Size at 16 bits | 2.20 GB | Memory the numbers take in the uncompressed 16-bit format (parameters x 2 bytes). |
| Input and output word tables shared | no | Whether the table turning words into numbers is reused to turn numbers back into words, which saves memory. |

## Key terms

- **Original model (uncompressed)**: The model exactly as published, with nothing removed or simplified. It is the reference point: the best accuracy we can hope for, and the most memory.
- **Standard quantization**: The compression technique applied the usual way, treating every part of the model the same.
- **Our method**: Our approach: first measure which parts of the model are fragile, then compress the robust parts hard and leave the fragile parts mostly intact.
- **Standard method: activations**: Every layer's activations at 8 bits.
- **Sensitivity-guided framework: activations**: Each layer was tested for how much rounding its activations hurts; the average of 6 bits goes to the layers that suffer most.
- **Sensitivity-guided framework: activations from the weight plan**: No test of the activations: layers the weight plan protects or never prunes keep 8 bits, the rest drop to 4.
- **Standard KV cache compression**: Every layer's notes stored at 4 bits per number, and every earlier word kept.
- **Sensitivity-guided KV cache plan**: Each layer's keys and values get their own bits, spending the same average as the standard method where rounding hurts most, and layers that focus on few earlier words forget the rest.
- **Sensitivity-guided KV cache plan, bits only**: The same per-layer bits, but no layer forgets anything. Comparing it with the full plan separates the effect of choosing bits from the effect of forgetting.
- **Our method: weights and activations planned together**: Each layer was tested with its weights and its incoming numbers rounded together, at every pair of bit lengths in [4, 8, 16] x [4, 8, 16]; each layer then gets the pair that keeps the total damage smallest, using on average 6 bits per weight and 6 bits per incoming number. The better of that plan and the separate plans was then re-tested with every other layer already rounded and re-made from that, kept only if the fully rounded model did better.
- **Language model**: A program that has learned from large amounts of text to predict the next word. Chat assistants are built on these. The one used here is described under "Original model".
- **Compression**: Making the model smaller and faster by storing its numbers with less detail or removing some of them, ideally without making its answers worse.
- **Layer**: The model is a stack of similar building blocks called layers; text passes through them one after another.
- **Bits**: Computers store numbers as strings of 0s and 1s (bits). More bits per number keeps more detail but takes more space. The uncompressed model uses 16 bits per number.
- **FP16**: "16-bit floating point", the standard precise format the model is published in.
- **Sensitivity**: How much the model's predictions would suffer if a layer were changed. It is measured by checking how strongly each layer's numbers influence the model's mistakes on ordinary text. Here it is shown on a 0-to-1 scale, where 1 is the most sensitive layer and 0 the least.
- **Protected layer**: A sensitive layer that the plan keeps at 8 bits and does not trim.
- **Pruning**: Deleting the numbers that matter least, like cutting unimportant words from an essay.
- **Threshold**: The cut-off for protecting a layer. With 0.50, roughly the most sensitive 50% of layers are protected.
- **Calibration text**: A small sample of ordinary text used only to measure sensitivity. It is kept separate from the text used to test accuracy.
- **Embeddings and LM head**: The model's word dictionary: the table that turns words into numbers at the start, and numbers back into words at the end.
- **KV cache**: The model's short-term memory while writing: notes on every earlier word, kept so they don't have to be recomputed. It grows with the length of the text.
- **Keys and values**: The two notes each layer keeps per word. The key says what a word is about (used to decide where to look), the value holds what it contributes once looked at.
- **Attention**: How much the model looks at each earlier word when choosing the next one.
- **Forgetting (token eviction)**: Dropping the notes on earlier words that a layer hardly looks at, to save memory.

## Results

All versions were tested under exactly the same conditions (same data, same computer, same settings), so differences come from the method alone. A dash means the measure is not available at this stage.

| Version | Prediction error on test text (validation half) (lower is better) | Prediction error on unseen test text (held-out half) (lower is better) | Memory needed to store the model (GB, lower is better) | Highest graphics-card memory used while running (GB, lower is better) | Time to read the prompt (ms, lower is better) | Time to write each word (ms, lower is better) | Storage used per number in the model (bits, lower is better) | Share of the model's numbers removed | How much compression hits the fragile parts (lower is better) | Short-term memory needed for one long text (GB, lower is better) | Storage used per number in the notes (bits, lower is better) | Share of earlier words the notes keep | Expected accuracy loss from the notes (lower is better) | Share of the model's focus that survives forgetting (higher is better) | Storage used per number passed between layers (bits, lower is better) | Expected accuracy loss from rounding the numbers passed between layers (lower is better) | Storage per weight in the repeated layers (bits, lower is better) | Expected accuracy loss from rounding a layer's weights and incoming numbers at the same time (lower is better) | Time to prepare the compressed model (s, lower is better) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Original model (uncompressed) | 10.18 | 10.62 | 2.2 | 2.41 | 5.86 | 4.26 | 16 | 0 | 0 | 0.0461 | 16 | 1 | 0 | 1 | – | – | – | – | 0 |
| Standard quantization | – | – | 0.777 | – | – | – | 5.65 | 0 | 0.75 | – | – | – | – | – | – | – | – | – | 0 |
| Our method | – | – | 1 | – | – | – | 7.29 | 0.132 | 0.577 | – | – | – | – | – | – | – | – | – | 122.02 |
| Standard method: activations | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 8 | 0.00718 | – | – | 0 |
| Sensitivity-guided framework: activations | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 6 | 0.53 | – | – | 238.24 |
| Sensitivity-guided framework: activations from the weight plan | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 6 | 0.645 | – | – | 0 |
| Standard KV cache compression | – | – | – | – | – | – | – | – | – | 0.013 | 4 | 1 | 0.108 | 1 | – | – | – | – | 0 |
| Sensitivity-guided KV cache plan | – | – | – | – | – | – | – | – | – | 0.00323 | 3.82 | 0.259 | 0.108 | 0.967 | – | – | – | – | 708.89 |
| Sensitivity-guided KV cache plan, bits only | – | – | – | – | – | – | – | – | – | 0.0128 | 3.95 | 1 | 0.108 | 1 | – | – | – | – | 708.89 |
| Our method: weights and activations planned together | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 6 | – | 6 | 0.691 | 2,015 |

**What each column means**

- **Version**: Which version of the model the row describes (see Key terms above).
- **Prediction error on test text (validation half)**: Perplexity measures how well the model predicts the next word of real text it has not been trained on. Think of it as how many words the model is "torn between" at each step: lower means more confident, correct predictions, so a more accurate model. Compression usually raises it a little; a small rise is acceptable, a large rise means the model got noticeably worse at language. The validation half is the part of the test text that is allowed to guide tuning.
- **Prediction error on unseen test text (held-out half)**: Perplexity measures how well the model predicts the next word of real text it has not been trained on. Think of it as how many words the model is "torn between" at each step: lower means more confident, correct predictions, so a more accurate model. Compression usually raises it a little; a small rise is acceptable, a large rise means the model got noticeably worse at language. The held-out half is never used for tuning, so it is the honest check that results were not tuned to one particular piece of text.
- **Memory needed to store the model**: How much memory the model would need after compression, in gigabytes, calculated from the plan before anything is actually compressed. Smaller means it fits on cheaper devices, such as laptops or phones.
- **Highest graphics-card memory used while running**: The most graphics-card memory the model needed at any moment while it was being tested.
- **Time to read the prompt**: How long the model takes to read the user's question before it starts answering, in milliseconds.
- **Time to write each word**: How long the model takes to produce each word (strictly, each word-piece) of its answer, in milliseconds. Lower means faster replies.
- **Storage used per number in the model**: A model is made of a huge number of numbers (see Original model). The original stores each one with 16 bits (binary digits); compression stores most of them with fewer bits, like rounding prices to the nearest dollar instead of the nearest cent. Fewer bits means a smaller model, but too few loses detail.
- **Share of the model's numbers removed**: Pruning deletes numbers that matter least. This is the share of all the model's numbers that the plan deletes (0.1 means 10%).
- **How much compression hits the fragile parts**: A score from 0 to 1 for how much of the compression lands on the model's most fragile layers. 0 means the fragile layers are untouched; higher means they are squeezed harder. Lower is better because squeezing fragile layers is what damages accuracy.
- **Short-term memory needed for one long text**: While writing, the model keeps notes on every earlier word (the KV cache). This is how much memory those notes would need for the text length set in the report, calculated from the plan.
- **Storage used per number in the notes**: How many bits each number in the model's notes is stored with, on average (16 uncompressed).
- **Share of earlier words the notes keep**: The plan can let some layers forget earlier words that get almost no attention. 1 means nothing is forgotten; 0.5 means half of the notes are dropped.
- **Expected accuracy loss from the notes**: The measured rise in prediction error when each layer's notes are rounded as planned, added up over layers. It is a prediction; Stage 3 measures the real perplexity (with rounding and forgetting simulated).
- **Share of the model's focus that survives forgetting**: When a layer forgets earlier words, this is the share of its attention that fell on the words it kept, averaged over layers. 1 means nothing it looked at was dropped.
- **Storage used per number passed between layers**: How many bits the numbers flowing between the model's layers are rounded to, on average over the layers (16 uncompressed). Planned here, applied in Stage 1.
- **Expected accuracy loss from rounding the numbers passed between layers**: Stage 0 rounded each layer's incoming numbers on its own and measured how much the prediction error (perplexity) rose. This adds those rises up for the plan's bits. Smaller is better.
- **Storage per weight in the repeated layers**: How many bits each weight of the model's repeated layers is stored with, on average (16 uncompressed); the input and output word tables are not included.
- **Expected accuracy loss from rounding a layer's weights and incoming numbers at the same time**: Stage 0 rounded each layer's weights and its incoming numbers together, at every pair of bit lengths, and measured how much the prediction error (perplexity) rose. This adds those rises up for the plan's pairs. Smaller is better.
- **Time to prepare the compressed model**: How long it took, in seconds, to produce this version of the model. This is a one-off cost paid before the model is used.

## Sensitivity of every layer

Sensitivity runs from 0 (least sensitive layer) to 1 (most sensitive). The raw score is the measurement before it is put on that scale. "Protected" layers keep high precision; the others are compressed and have the listed share of their numbers removed. The last three columns are the short-term memory (KV cache) plan: bits for keys, bits for values, and the share of earlier words kept.

| Layer | Sensitivity (0 to 1) | Raw score | Protected (framework plan) | Share removed (framework plan) | Never pruned | Activation bits (framework) | Activation damage at fewest bits | Unusual layer | Key bits (cache) | Value bits (cache) | Share of words kept (cache) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 1.00 | 1,176 | yes | 0.00 | yes | 4 | 0.07 | yes | 4 | 2 | 1.00 |
| 1 | 0.81 | 11.57 | yes | 0.00 | yes | 8 | 0.73 | yes | 4 | 4 | 0.75 |
| 2 | 0.95 | 368 | yes | 0.00 | yes | 8 | 0.16 | yes | 4 | 4 | 0.75 |
| 3 | 0.52 | 2.86 | yes | 0.00 |  | 4 | 0.04 |  | 4 | 4 | 0.30 |
| 4 | 0.24 | 2.01 |  | 0.30 |  | 4 | 0.05 |  | 4 | 4 | 0.10 |
| 5 | 0.33 | 2.25 |  | 0.30 |  | 4 | 0.03 |  | 4 | 4 | 0.10 |
| 6 | 0.38 | 2.34 |  | 0.30 |  | 8 | 0.14 |  | 4 | 4 | 0.20 |
| 7 | 0.90 | 36.47 | yes | 0.00 | yes | 8 | 0.08 | yes | 4 | 4 | 0.50 |
| 8 | 0.29 | 2.17 |  | 0.30 |  | 4 | 0.06 |  | 4 | 4 | 0.10 |
| 9 | 0.19 | 1.98 |  | 0.30 |  | 4 | 0.04 |  | 4 | 4 | 0.10 |
| 10 | 0.00 | 1.42 |  | 0.30 |  | 4 | 0.04 |  | 4 | 4 | 0.10 |
| 11 | 0.05 | 1.42 |  | 0.30 |  | 4 | 0.06 |  | 4 | 4 | 0.10 |
| 12 | 0.14 | 1.83 |  | 0.30 |  | 4 | 0.03 |  | 4 | 4 | 0.20 |
| 13 | 0.10 | 1.68 |  | 0.30 |  | 4 | 0.07 |  | 4 | 4 | 0.20 |
| 14 | 0.48 | 2.78 |  | 0.30 |  | 4 | 0.05 |  | 4 | 4 | 0.20 |
| 15 | 0.67 | 3.91 | yes | 0.00 |  | 8 | 0.07 |  | 4 | 4 | 0.10 |
| 16 | 0.71 | 4.10 | yes | 0.00 |  | 8 | 0.08 |  | 4 | 4 | 0.20 |
| 17 | 0.43 | 2.66 |  | 0.30 |  | 8 | 0.08 |  | 4 | 4 | 0.10 |
| 18 | 0.62 | 3.68 | yes | 0.00 |  | 8 | 0.10 |  | 4 | 4 | 0.20 |
| 19 | 0.57 | 3.58 | yes | 0.00 |  | 8 | 0.08 |  | 4 | 4 | 0.10 |
| 20 | 0.76 | 5.68 | yes | 0.00 |  | 8 | 0.11 |  | 4 | 4 | 0.10 |
| 21 | 0.86 | 23.61 | yes | 0.00 | yes | 8 | 0.17 | yes | 4 | 4 | 0.20 |

**What each column means**

- **Layer**: The layer's position in the model, counting from 0 at the input end.
- **Sensitivity (0 to 1)**: The layer's rank among all layers: 0 is the least sensitive layer, 1 the most. The plans compare this with the threshold.
- **Raw score**: How much the prediction error (perplexity) on the calibration text rises when this layer is skipped. Bigger means the model depends on the layer more.
- **Protected (framework plan)**: "yes" if the framework plan keeps this layer at high precision because its sensitivity is at or above the threshold.
- **Share removed (framework plan)**: Share of the layer's numbers the framework plan deletes (0.3 means 30%); protected and guarded layers lose nothing.
- **Never pruned**: "yes" for the layers the model depends on most (removing one alone hurts the most), which no plan may trim, whatever their sensitivity score.
- **Activation bits (framework)**: Bits for the numbers flowing into this layer, planned for Stage 1.
- **Activation damage at fewest bits**: How much the prediction error (perplexity) rose when only this layer's incoming numbers were rounded to the fewest bits allowed. Bigger means the layer needs more bits. Empty when activations were not measured.
- **Unusual layer**: "yes" if the raw score is far from the other layers' (robust z-score above 3.5), so the layer stands out as much more (or less) sensitive than the rest.
- **Key bits (cache)**: Bits per number for this layer's stored keys (the notes used to decide which earlier words matter).
- **Value bits (cache)**: Bits per number for this layer's stored values (the content taken from earlier words).
- **Share of words kept (cache)**: Share of earlier words this layer keeps notes on; 1.00 keeps all, 0.10 keeps the 10% that get the most attention.

## Findings

- **Our method** is a trade-off against the standard method: better on some measures, worse on others (better on how much compression hits the fragile parts; worse on memory needed to store the model, storage used per number in the model). It costs more to prepare: time to prepare the compressed model (122.02 s more, paid once).
- **Sensitivity-guided framework: activations** is a trade-off against the standard method: better on some measures, worse on others (better on storage used per number passed between layers; worse on expected accuracy loss from rounding the numbers passed between layers). It costs more to prepare: time to prepare the compressed model (238.24 s more, paid once).
- **Sensitivity-guided framework: activations from the weight plan** is a trade-off against the standard method: better on some measures, worse on others (better on storage used per number passed between layers; worse on expected accuracy loss from rounding the numbers passed between layers).
- **Sensitivity-guided KV cache plan** is a trade-off against the standard method: better on some measures, worse on others (better on short-term memory needed for one long text, storage used per number in the notes; worse on share of the model's focus that survives forgetting). It costs more to prepare: time to prepare the compressed model (708.89 s more, paid once).
- **Sensitivity-guided KV cache plan, bits only** beat the standard method on every measure compared (better on short-term memory needed for one long text, storage used per number in the notes). It costs more to prepare: time to prepare the compressed model (708.89 s more, paid once).
- There is no working standard quantization result for joint_weights_activations, so the framework could not be compared against it.
- Keeping the sensitive layers at higher precision costs space, so the framework's model is predicted to be larger (1 GB against 0.777 GB for the standard method).
- In return, far less of the compression lands on the fragile layers (a score of 0.58 against 0.75, where lower is safer). Damage to the fragile layers is what hurts accuracy, so the framework's model is expected to stay closer to the original.
- Because the framework's plan is bigger, comparing its accuracy with the standard method would not be fair: some of any gain would come simply from using more memory.
- Some parts of the model (the word dictionary at its input and output, called embeddings and the LM head) stay uncompressed in every plan. They alone take 0.26 GB, about 34% of the standard method's size, so no plan here can get the model smaller than that.
- Warning: layer 0 behaves very differently from all the others (its sensitivity score is unusually high). The plan protects it based on that score. Unusual layers, especially the first, can matter more than the score suggests, so this layer should be checked before relying on the plan.
- Warning: layer 1 behaves very differently from all the others (its sensitivity score is unusually high). The plan protects it based on that score. Unusual layers, especially the first, can matter more than the score suggests, so this layer should be checked before relying on the plan.
- Warning: layer 2 behaves very differently from all the others (its sensitivity score is unusually high). The plan protects it based on that score. Unusual layers, especially the first, can matter more than the score suggests, so this layer should be checked before relying on the plan.
- Warning: layer 7 behaves very differently from all the others (its sensitivity score is unusually high). The plan protects it based on that score. Unusual layers, especially the first, can matter more than the score suggests, so this layer should be checked before relying on the plan.
- Warning: layer 21 behaves very differently from all the others (its sensitivity score is unusually high). The plan protects it based on that score. Unusual layers, especially the first, can matter more than the score suggests, so this layer should be checked before relying on the plan.
- For the short-term memory, rounding one layer's keys to 2 bits raised the prediction error by 0.0687 on average, against 0.0567 for values, so keys are the more fragile notes. With the same average bits as the standard method (4), the plan's predicted accuracy loss from rounding is 0.108 against 0.108 for the standard method (lower is better). 21 of 22 layers can forget part of the text while keeping 95% of their attention, which brings the notes for a 2048-token text (a token is about three quarters of a word) from 0.013 GB to 0.00323 GB (uncompressed: 0.0461 GB).
- Whether the trade pays off (similar accuracy at a similar or smaller size) is only proven once Stage 1 applies the plans and measures their actual accuracy.
- Original model (uncompressed) misses a deployment target (target_memory_gb).
- Standard quantization meets every deployment target that was set.
- Our method meets every deployment target that was set.

## How this stage works

Compressing a language model is like shrinking a photo: done carefully, you save a lot of space and barely notice the difference; done carelessly, the picture turns to mush. The catch is that not every part of the model is equally delicate. Some layers can be squeezed hard with no visible effect, while others fall apart at the slightest change.

Stage 0 finds out which is which, in four steps.

1. **Measure.** The model reads 64 short passages of ordinary text (wikitext2) and tries to predict each next word. Then one layer at a time is switched off (skipped, so the text passes straight through it) and the passages are read again. How much the prediction error (perplexity) rises is that layer's raw sensitivity score: the bigger the rise, the more the model depends on it. This is done for each of the 22 layers.
2. **Rank.** The 22 raw scores are put in order and turned into a 0-to-1 scale: the least sensitive layer gets 0, the most sensitive gets 1, and the rest are spaced evenly between by their position in the order. Using the order rather than the raw values stops one unusual layer from squashing all the others together.
3. **Choose.** Every layer at or above the threshold (0.50) is **protected**; the rest are **compressed**. A threshold of 0.50 protects roughly the most sensitive 50% of layers.
4. **Allocate.** Protected layers keep 8 bits per number and lose nothing. Compressed layers get 4 bits per number and have 30% of their numbers removed.

The idea being tested is simple: spend the memory where damage hurts most. Whether it works is decided by accuracy, which Stage 1 measures.

Nothing is actually compressed yet. Stage 0 only makes the plan and predicts how big the model would be. Later stages carry out the plan and measure the real accuracy and speed.

Stage 0 also plans the model's **short-term memory** (the KV cache). While writing, the model keeps two notes (a *key* and a *value*) about every earlier word in every layer, so it doesn't have to reread the whole text for each new word. For long texts these notes can take more memory than the model itself. The same idea is applied to them: each layer's keys, then its values, are rounded to fewer bits one at a time to see how much that hurts, and each layer's attention is checked to see whether it only looks at a few earlier words. The plan then gives fragile notes more bits, robust ones fewer, and lets layers that focus on few words forget the rest.

---

# Technical details

## What was run

- `baseline/fp16`: uncompressed model
- `allocation/original`: uniform 4-bit, prune 0.0 on every layer
- `allocation/framework`: sensitivity plan (threshold 0.5, prune 0.3 on robust layers)
- `activations/original`: uniform 8-bit activations
- `activations/framework`: measured plan, 6 average bits over [4, 8]
- `activations_from_weights/framework`: 8-bit on layers the weight plan protects or never prunes, 4-bit elsewhere
- `kv_cache/original`: uniform 4-bit keys and values, no eviction
- `kv_cache/framework`: per-layer key/value bits at 4 average bits, per-layer token budget keeping 95% of attention
- `kv_cache_bits_only/framework`: per-layer key/value bits at 4 average bits, no eviction
- `joint_weights_activations/framework`: joint plan, weights avg 6 over [4, 8, 16], activations avg 6 over [4, 8, 16]

Every row shares these conditions:

- **model**: TinyLlama/TinyLlama-1.1B-Chat-v1.0
- **calibration**: wikitext2, 64 x 512 tokens
- **seed**: 0
- **evaluation data**: wikitext-2 test, 512-token windows, validation/held-out halves
- **device**: cuda
- **backend**: HF Transformers
- **group size for memory prediction**: 128
- **KV cache memory prediction**: 2048 tokens x 1 sequence(s)

Original model (from its config):

- **name**: TinyLlama/TinyLlama-1.1B-Chat-v1.0
- **architecture**: LlamaForCausalLM
- **num_parameters**: 1100048384
- **num_layers**: 22
- **hidden_size**: 2048
- **intermediate_size**: 5632
- **num_attention_heads**: 32
- **num_key_value_heads**: 4
- **head_dim**: 64
- **vocab_size**: 32000
- **max_context**: 2048
- **published_dtype**: bfloat16
- **bits_per_parameter**: 16
- **fp16_size_gb**: 2.2
- **tied_embeddings**: no

## Environment

- **python**: 3.13.15
- **platform**: Linux-6.6.122+-x86_64-with-glibc2.39
- **git_commit**: ac990ae
- **git_dirty**: no
- **torch**: 2.11.0+cu130
- **transformers**: 5.20.1
- **datasets**: 4.8.5
- **numpy**: 2.5.4
- **openpyxl**: 3.1.5
- **optuna**: 5.0.0
- **pymoo**: 0.6.2
- **cuda_available**: yes
- **gpu**: NVIDIA A100-SXM4-80GB
- **gpu_count**: 1
- **cuda**: 13.0

## Results

| Row | Status | Perplexity (validation half) | Perplexity (held-out half) | Predicted weight memory | Peak GPU memory | Prefill latency (mean) | Decode latency per token (mean) | Average bits per weight | Weight sparsity | Sensitivity exposure | Predicted KV-cache memory | Average bits per cached number | Share of past tokens kept | Predicted perplexity rise from cache rounding | Attention on kept tokens | Average activation bits | Predicted perplexity rise from activation rounding | Average weight bits in the decoder layers | Predicted perplexity rise from weight and activation rounding together | Build time | Requirement met |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `baseline/fp16` | ok | 10.18 | 10.62 | 2.2 | 2.414 | 5.858 | 4.258 | 16 | 0 | 0 | 0.04614 | 16 | 1 | 0 | 1 | – | – | – | – | 0 | no |
| `allocation/original` | ok | – | – | 0.777 | – | – | – | 5.651 | 0 | 0.75 | – | – | – | – | – | – | – | – | – | 0 | yes |
| `allocation/framework` | ok | – | – | 1.003 | – | – | – | 7.291 | 0.1321 | 0.5774 | – | – | – | – | – | – | – | – | – | 122 | yes |
| `activations/original` | ok | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 8 | 0.007176 | – | – | 0 | n/a (not all targets measurable yet) |
| `activations/framework` | ok | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 6 | 0.5303 | – | – | 238.2 | n/a (not all targets measurable yet) |
| `activations_from_weights/framework` | ok | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 6 | 0.6446 | – | – | 0 | n/a (not all targets measurable yet) |
| `kv_cache/original` | ok | – | – | – | – | – | – | – | – | – | 0.01298 | 4 | 1 | 0.1084 | 1 | – | – | – | – | 0 | n/a (not all targets measurable yet) |
| `kv_cache/framework` | ok | – | – | – | – | – | – | – | – | – | 0.003232 | 3.825 | 0.2592 | 0.1084 | 0.9672 | – | – | – | – | 708.9 | n/a (not all targets measurable yet) |
| `kv_cache_bits_only/framework` | ok | – | – | – | – | – | – | – | – | – | 0.01285 | 3.955 | 1 | 0.1084 | 1 | – | – | – | – | 708.9 | n/a (not all targets measurable yet) |
| `joint_weights_activations/framework` | ok | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 6 | – | 6 | 0.6911 | 2015 | n/a (not all targets measurable yet) |

**What each column means**

- **Row**: Method and version, as `method/variant`: `fp16` is the uncompressed model, `original` the method used the standard way, `framework` the method guided by Stage 0.
- **Status**: `ok` if the row finished, `failed` if it raised an error (the error is under Anomalies).
- **Perplexity (validation half)**: Prediction error on test text (validation half) (lower is better).
- **Perplexity (held-out half)**: Prediction error on unseen test text (held-out half) (lower is better).
- **Predicted weight memory**: Memory needed to store the model (GB, lower is better).
- **Peak GPU memory**: Highest graphics-card memory used while running (GB, lower is better).
- **Prefill latency (mean)**: Time to read the prompt (ms, lower is better).
- **Decode latency per token (mean)**: Time to write each word (ms, lower is better).
- **Average bits per weight**: Storage used per number in the model (bits, lower is better).
- **Weight sparsity**: Share of the model's numbers removed.
- **Sensitivity exposure**: How much compression hits the fragile parts (lower is better).
- **Predicted KV-cache memory**: Short-term memory needed for one long text (GB, lower is better).
- **Average bits per cached number**: Storage used per number in the notes (bits, lower is better).
- **Share of past tokens kept**: Share of earlier words the notes keep.
- **Predicted perplexity rise from cache rounding**: Expected accuracy loss from the notes (lower is better).
- **Attention on kept tokens**: Share of the model's focus that survives forgetting (higher is better).
- **Average activation bits**: Storage used per number passed between layers (bits, lower is better).
- **Predicted perplexity rise from activation rounding**: Expected accuracy loss from rounding the numbers passed between layers (lower is better).
- **Average weight bits in the decoder layers**: Storage per weight in the repeated layers (bits, lower is better).
- **Predicted perplexity rise from weight and activation rounding together**: Expected accuracy loss from rounding a layer's weights and incoming numbers at the same time (lower is better).
- **Build time**: Time to prepare the compressed model (s, lower is better).
- **Requirement met**: Whether the row meets every deployment target that was set; `no targets set` when the run set none, `n/a` when a target cannot be measured at this stage.

Full metrics, deltas and raw measurements are in `stage_0_comparison.xlsx` and `results.json`.

## Key findings

- **allocation**: the framework trades off against the original method. Better on Sensitivity exposure (-0.1726, -23.0%). Worse on Predicted weight memory (+0.2256, +29.0%); Average bits per weight (+1.64, +29.0%). One-off cost: Build time (+122).
- **activations**: the framework trades off against the original method. Better on Average activation bits (-2, -25.0%). Worse on Predicted perplexity rise from activation rounding (+0.5232, +7290.4%). One-off cost: Build time (+238.2).
- **activations_from_weights**: the framework trades off against the original method. Better on Average activation bits (-2, -25.0%). Worse on Predicted perplexity rise from activation rounding (+0.6374, +8882.1%).
- **kv_cache**: the framework trades off against the original method. Better on Predicted KV-cache memory (-0.009744, -75.1%); Average bits per cached number (-0.1754, -4.4%). Worse on Attention on kept tokens (-0.03283, -3.3%). One-off cost: Build time (+708.9).
- **kv_cache_bits_only**: the framework beats the original method. Better on Predicted KV-cache memory (-0.0001311, -1.0%); Average bits per cached number (-0.04545, -1.1%). One-off cost: Build time (+708.9).
- **joint_weights_activations**: no original-method row to compare against.
- baseline/fp16 misses the deployment requirement: target_memory_gb over by 1.1.

## Sensitivity profile and plan

Score: layer_removal, rank-normalised to [0, 1] over 22 decoder layers.
Most sensitive layers: 0 (1.00), 2 (0.95), 7 (0.90). Least sensitive: 13 (0.10), 11 (0.05), 10 (0.00).
Protected (11/22): [0, 1, 2, 3, 7, 15, 16, 18, 19, 20, 21].
Profiling cost: 64 batches, 32768 tokens, 122.0s, peak GPU memory 4.60 GB.

Stage 0 only allocates precision, so memory here is predicted from the plan. Accuracy and latency of the two allocations are measured once Stages 1 and 2 apply them.

## Pruning guard

Never pruned in any framework plan: layers [0, 1, 2, 7, 21], the 5 whose removal raises perplexity most (layer-removal score). They keep the bits their plan gives them; only pruning is blocked.

## Activation plan (for Stage 1)

Activation bits per layer are measured: each layer's Linear inputs were rounded to each of [4, 8] bits on its own and the perplexity rise recorded; the average budget goes where the rise is largest. Layers at the highest width: [1, 2, 6, 7, 15, 16, 17, 18, 19, 20, 21]; average 6.00 bits. Saved as activation_plan.json (measurements in activation_profile.json).

## Size floor

Embeddings, the LM head and norms (131,164,160 parameters) stay at 16 bits in every plan: 0.262 GB, 34% of the uniform plan's predicted size. No layer allocation can go below this floor; compressing the embeddings / LM head is the only way past it.

## KV cache plan

Measured on 64 batches (32768 tokens) in 708.9s. Keys rounded per channel, values per token, groups of 64; keys before RoPE.
Mean perplexity rise with one layer's cache at 2 bits: keys 0.06871, values 0.05674.
Key bits per layer: [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4].
Value bits per layer: [2, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4].
Layers that evict tokens (21/22): 1 (keep 75%), 2 (keep 75%), 3 (keep 30%), 4 (keep 10%), 5 (keep 10%), 6 (keep 20%), 7 (keep 50%), 8 (keep 10%), 9 (keep 10%), 10 (keep 10%), 11 (keep 10%), 12 (keep 20%), 13 (keep 20%), 14 (keep 20%), 15 (keep 10%), 16 (keep 20%), 17 (keep 10%), 18 (keep 20%), 19 (keep 10%), 20 (keep 10%), 21 (keep 20%); target: kept tokens receive 95% of attention.
Predicted cache memory at 2048 tokens x 1 sequence(s): FP16 0.04614 GB, uniform 4-bit 0.01298 GB, plan 0.003232 GB, plan without eviction 0.01285 GB.

Attention coverage takes each query's top tokens (an oracle); H2O / SnapKV choose tokens from past attention and keep a little less. Perplexity rises are summed over layers, assuming they add up. Stage 3 measures the real perplexity with each technique's own choice of words (simulated).

## Perplexity against WxAy per layer

Written: joint_curves.csv and the figures in joint_curves/. Each layer's calibration perplexity with only that layer rounded, at every weight x activation bit pair, and the pair the joint plan chose.

## Pruning levels test (for Stage 2)

Wanda, structured and low-rank pruning at 7 levels on all, non-guarded and guarded-only layers: see ../stage_0_pruning_levels/report.md.

## What later stages receive

See handoff.md: the plan each stage loads, layer by layer, with its predicted cost.

## Anomalies and failures

- Layer 0 is an outlier: raw sensitivity 1176, above every other layer (1.415–368). The plan has it protected. Check this layer's quality separately before trusting the plan for it.
- Layer 1 is an outlier: raw sensitivity 11.57, far from every other layer (1.415–1176). The plan has it protected. Check this layer's quality separately before trusting the plan for it.
- Layer 2 is an outlier: raw sensitivity 368, far from every other layer (1.415–1176). The plan has it protected. Check this layer's quality separately before trusting the plan for it.
- Layer 7 is an outlier: raw sensitivity 36.47, far from every other layer (1.415–1176). The plan has it protected. Check this layer's quality separately before trusting the plan for it.
- Layer 21 is an outlier: raw sensitivity 23.61, far from every other layer (1.415–1176). The plan has it protected. Check this layer's quality separately before trusting the plan for it.

## Suggested next steps

- Run Stage 1 (GPTQ) with the standard and framework plans to measure their perplexity and latency.
- If sensitivity exposure is high, raise sensitive_threshold or lower prune_ratio_aggressive.
- Run Stage 3 (KVQuant, H2O, SnapKV) with the KV cache plan to measure its real accuracy.
