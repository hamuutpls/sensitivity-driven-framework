# What Stage 0 hands to each stage

Stage 0 does not compress anything. It measures which parts of the model are fragile and writes a plan for every later stage: how many bits each layer's weights and the numbers passed between layers get (Stage 1, quantization only: nothing is removed), how much of each layer may be removed (Stage 2, pruning only: nothing is rounded), and how the model's short-term memory while writing is stored (Stage 3). Stage 4 and the search use the plans' predicted costs and the uncompressed model's measured numbers as their reference. Every plan below is also a JSON file next to this one, and each later stage loads that file rather than re-measuring.

Each stage applies its plan on its own, starting from the original model, so the effect of each kind of compression can be measured separately: paths 0 > 1 > 4, 0 > 2 > 4 and 0 > 3 > 4. One more path, 0 > 1 > 2 > 4, runs a pruning method on a model Stage 1 has already quantized. Every stage compares three versions under identical conditions: the original model, the method used the standard way (no Stage 0), and the method guided by Stage 0.

## Original model

Every version in this report starts from this model, unchanged as published.

| What | Value | What it means |
|---|---|---|
| Model | TinyLlama/TinyLlama-1.1B-Chat-v1.0 | The published model every result in this report starts from. |
| Architecture | LlamaForCausalLM | The model family's design; models of the same family are built the same way. |
| Parameters | 1,100,048,384 (1.10 billion) | How many numbers the model has learned. More numbers usually means a more capable but bigger and slower model. |
| Layers | 22 | How many similar building blocks the text passes through, one after another. Stage 0 measures each one separately. |
| Hidden size | 2,048 | How many numbers describe each word inside the model, as it passes from layer to layer. |
| Feed-forward size | 5,632 | How wide the "thinking" part inside each layer is, in numbers per word. |
| Attention heads | 32 | How many separate ways each layer looks back at earlier words at the same time. |
| Key/value heads | 4 | How many sets of notes each layer stores about earlier words (the KV cache). Fewer than the attention heads means the notes are shared, which saves memory. |
| Numbers per head | 64 | How many numbers each attention head uses per word. |
| Vocabulary | 32,000 | How many different word pieces (tokens) the model knows. |
| Maximum context | 2,048 tokens | The most tokens (word pieces) the model can read and write at once. |
| Published number format | bfloat16 | How the numbers are stored in the published model files. |
| Bits per number | 16 bits | Storage per number in the uncompressed model; compression lowers this. |
| Size at 16 bits | 2.20 GB | Memory the numbers take in the uncompressed 16-bit format (parameters x 2 bytes). |
| Input and output word tables shared | no | Whether the table turning words into numbers is reused to turn numbers back into words, which saves memory. |

## At a glance

| Who | Receives | File | How to load |
|---|---|---|---|
| Stage 1: weights | bits per layer, nothing removed | `quant_plan.json` | `CompressionPlan.load` |
| Stage 1: activations | bits per layer for the numbers passed between layers | `activation_plan.json` (+ `activation_profile.json`) | `ActivationPlan.load` |
| Stage 1: weights and activations together | a weight and an activation bit length per layer, planned together | `joint_weight_plan.json` + `joint_activation_plan.json` | `CompressionPlan.load`, `ActivationPlan.load` |
| Stage 2: pruning | share removed per layer (nothing rounded); layers never to prune | `prune_plan.json` (+ `prune_plan_same_size.json`); one pair per pruning level, `prune_plan_<level>.json` + `prune_plan_same_size_<level>.json` (e.g. `_030` for 30%), which Stage 2 runs | `CompressionPlan.load` |
| Stage 3: KV cache | key bits, value bits and share of past words kept per layer | `kv_cache_plan.json` (+ `_bits_only`, `kv_profile.json`) | `KVPlan.load` |
| Stage 4: evaluation | the uncompressed model's measured numbers and the conditions to repeat | `results.json` (row `baseline/fp16`) | read the JSON |
| Search | Stage 0's search parameters, cached measurements, cheap predicted costs per trial | `sensitivity_profile.json`, cache folder | `run_stage0` per trial |

**What each column means**

- **Who**: The later stage (or the search) that uses this part of the plan.
- **Receives**: What the plan tells that stage to do.
- **File**: The file Stage 0 writes, in the same folder as this report.
- **How to load**: The Python call that reads the file back into a plan object.

## Stage 1: quantization (weights: RTN, GPTQ, AWQ; activations: SmoothQuant, QuaRot, RPTQ, SpinQuant)

Quantization keeps every number with fewer bits and removes nothing. This holds for every plan below.

### Weights

Our method protects layers with sensitivity at or above 0.50 (11 of 22: kept at 8 bits) and compresses the rest to 4 bits, mixing bit lengths across layers. Standard quantization gives every layer the same 4 bits.

| Layer | Sensitivity | Protected | Bits |
|---|---|---|---|
| 0 | 1.00 | yes | 8 |
| 1 | 0.81 | yes | 8 |
| 2 | 0.95 | yes | 8 |
| 3 | 0.52 | yes | 8 |
| 4 | 0.24 |  | 4 |
| 5 | 0.33 |  | 4 |
| 6 | 0.38 |  | 4 |
| 7 | 0.90 | yes | 8 |
| 8 | 0.29 |  | 4 |
| 9 | 0.19 |  | 4 |
| 10 | 0.00 |  | 4 |
| 11 | 0.05 |  | 4 |
| 12 | 0.14 |  | 4 |
| 13 | 0.10 |  | 4 |
| 14 | 0.48 |  | 4 |
| 15 | 0.67 | yes | 8 |
| 16 | 0.71 | yes | 8 |
| 17 | 0.43 |  | 4 |
| 18 | 0.62 | yes | 8 |
| 19 | 0.57 | yes | 8 |
| 20 | 0.76 | yes | 8 |
| 21 | 0.86 | yes | 8 |

**What each column means**

- **Layer**: Position in the model, from 0 at the input end.
- **Sensitivity**: How much the model suffers when this layer changes, from 0 (least) to 1 (most), measured by layer removal.
- **Protected**: "yes" if our method keeps this layer at high precision.
- **Bits**: Bits per number for this layer's weights in our method.

| Version | Predicted size | Average bits per number |
|---|---|---|
| Original model (uncompressed) | 2.200 GB | 16 |
| Standard quantization (uniform 4-bit) | 777.0 MB | 5.65 |
| Our method | 1.019 GB | 7.41 |

**What each column means**

- **Version**: Which plan the row describes.
- **Predicted size**: Memory for the model's numbers, predicted from the plan (group size 128). Stage 1 measures the real size.
- **Average bits per number**: Storage per number over the whole model, including parts never compressed (16 means uncompressed).

Stage 1 also takes the search parameter `gptq_groupsize` (now 128). It must measure what Stage 0 only predicts: real size, perplexity on both halves of the test text, speed and peak memory, for each plan against the standard method.

### Activations

Each layer's incoming numbers were rounded on their own to each of 4, 8 bits on 64 passages, and the rise in prediction error was recorded. The plan spends an average of 6 bits per layer, giving the most bits to the layers that suffer most. Stage 1 applies its smoothing or rotation to every layer and rounds each layer's activations to the planned bits.

| Layer | Activation bits | Bits if copied from the weight plan | Damage at 4 bits | Damage at 8 bits |
|---|---|---|---|---|
| 0 | 4 | 8 | +0.0690 | +0.0005 |
| 1 | 8 | 8 | +0.7266 | +0.0016 |
| 2 | 8 | 8 | +0.1580 | -0.0001 |
| 3 | 4 | 8 | +0.0355 | -0.0002 |
| 4 | 4 | 4 | +0.0456 | -0.0002 |
| 5 | 4 | 4 | +0.0253 | +0.0006 |
| 6 | 8 | 4 | +0.1367 | +0.0001 |
| 7 | 8 | 8 | +0.0821 | +0.0000 |
| 8 | 4 | 4 | +0.0646 | -0.0002 |
| 9 | 4 | 4 | +0.0427 | +0.0011 |
| 10 | 4 | 4 | +0.0388 | -0.0005 |
| 11 | 4 | 4 | +0.0592 | -0.0002 |
| 12 | 4 | 4 | +0.0318 | +0.0005 |
| 13 | 4 | 4 | +0.0662 | +0.0006 |
| 14 | 4 | 4 | +0.0476 | -0.0009 |
| 15 | 8 | 8 | +0.0693 | -0.0000 |
| 16 | 8 | 8 | +0.0775 | +0.0000 |
| 17 | 8 | 4 | +0.0822 | +0.0006 |
| 18 | 8 | 8 | +0.0982 | +0.0011 |
| 19 | 8 | 8 | +0.0812 | +0.0005 |
| 20 | 8 | 8 | +0.1069 | -0.0004 |
| 21 | 8 | 8 | +0.1713 | -0.0025 |

**What each column means**

- **Layer**: Position in the model, from 0 at the input end.
- **Activation bits**: Bits Stage 1 rounds this layer's incoming numbers to.
- **Bits if copied from the weight plan**: What the cheaper rule (fragile for weights means fragile for activations) would give, for comparison.
- **Damage at 4 bits**: Rise in prediction error (perplexity) when only this layer's incoming numbers are rounded to the fewest bits. Values within about ±0.005 are measurement noise.
- **Damage at 8 bits**: The same at the most bits.

| Version | Average bits | Predicted perplexity rise |
|---|---|---|
| Standard method (uniform 8-bit) | 8.00 | 0.007176 |
| Plan | 6.00 | 0.5303 |
| Copied from the weight plan | 6.00 | 0.6446 |

**What each column means**

- **Version**: Which activation plan the row describes.
- **Average bits**: Bits per incoming number, averaged over the layers.
- **Predicted perplexity rise**: The measured per-layer damages added up for that plan (assumes they add up; Stage 1 measures the real effect). Lower is better; – means the plan uses a bit width that was not measured.

Stage 1 adds the search parameter `smoothquant_alpha` to the search space.

## Stage 2: pruning (Wanda, structured pruning, low-rank)

Pruning removes numbers and rounds nothing. Alone (0 > 2 > 4) it prunes the uncompressed model; after Stage 1 (0 > 1 > 2 > 4) it prunes the quantized model, using the Stage 1 bits above for the size. The pruning plan removes 30% of the numbers of every layer that is neither protected nor never-pruned. The same-size plan removes exactly as many numbers as the standard method (every layer pruned at 30%) but takes them from the least sensitive layers first. Layers 0, 1, 2, 7, 21 are never pruned in any plan, because removing any one of them alone hurts the model most (the 5 highest layer-removal scores).

| Layer | Never pruned | Removed | Removed (same-size plan) |
|---|---|---|---|
| 0 | yes | 0% | 0% |
| 1 | yes | 0% | 0% |
| 2 | yes | 0% | 0% |
| 3 |  | 0% | 31% |
| 4 |  | 30% | 47% |
| 5 |  | 30% | 42% |
| 6 |  | 30% | 39% |
| 7 | yes | 0% | 0% |
| 8 |  | 30% | 44% |
| 9 |  | 30% | 50% |
| 10 |  | 30% | 61% |
| 11 |  | 30% | 58% |
| 12 |  | 30% | 53% |
| 13 |  | 30% | 55% |
| 14 |  | 30% | 33% |
| 15 |  | 0% | 22% |
| 16 |  | 0% | 19% |
| 17 |  | 30% | 36% |
| 18 |  | 0% | 25% |
| 19 |  | 0% | 28% |
| 20 |  | 0% | 17% |
| 21 | yes | 0% | 0% |

**What each column means**

- **Layer**: Position in the model, from 0 at the input end.
- **Never pruned**: "yes" if no plan may remove numbers from this layer, whatever its sensitivity.
- **Removed**: Share of this layer's numbers the pruning plan deletes.
- **Removed (same-size plan)**: Share deleted in the plan that removes as many numbers as the standard method.

| Version | Predicted size (uncompressed weights) | Share removed |
|---|---|---|
| Original model (uncompressed) | 2.200 GB | 0% |
| Standard method (uniform, 30% of every layer) | 1.740 GB | 26% |
| Pruning plan | 1.970 GB | 13% |
| Same-size plan | 1.712 GB | 26% |

**What each column means**

- **Version**: Which plan the row describes.
- **Predicted size (uncompressed weights)**: Memory of the remaining numbers at 16 bits plus a record of which were kept; Stage 2 after Stage 1 stores them at Stage 1's bits.
- **Share removed**: Share of all the model's numbers deleted by pruning.

## Stage 3: KV cache (QuaRot KV, KVQuant, H2O, SnapKV, InfiniGen)

While writing, the model keeps notes on every earlier word (the KV cache). The plan sets, per layer, the bits for keys and for values (average 4, the standard method's size) and the share of earlier words kept (the fewest that still get 95% of the layer's attention). Measured on 64 passages.

| Layer | Key bits | Value bits | Words kept |
|---|---|---|---|
| 0 | 4 | 2 | 100% |
| 1 | 4 | 4 | 75% |
| 2 | 4 | 4 | 75% |
| 3 | 4 | 4 | 30% |
| 4 | 4 | 4 | 10% |
| 5 | 4 | 4 | 10% |
| 6 | 4 | 4 | 20% |
| 7 | 4 | 4 | 50% |
| 8 | 4 | 4 | 10% |
| 9 | 4 | 4 | 10% |
| 10 | 4 | 4 | 10% |
| 11 | 4 | 4 | 10% |
| 12 | 4 | 4 | 20% |
| 13 | 4 | 4 | 20% |
| 14 | 4 | 4 | 20% |
| 15 | 4 | 4 | 10% |
| 16 | 4 | 4 | 20% |
| 17 | 4 | 4 | 10% |
| 18 | 4 | 4 | 20% |
| 19 | 4 | 4 | 10% |
| 20 | 4 | 4 | 10% |
| 21 | 4 | 4 | 20% |

**What each column means**

- **Layer**: Position in the model, from 0 at the input end.
- **Key bits**: Bits per number for this layer's stored keys (what earlier words are about).
- **Value bits**: Bits per number for this layer's stored values (what earlier words say).
- **Words kept**: Share of earlier words this layer remembers; the rest are forgotten.

| Version | Predicted memory (2048 words) | Average bits | Predicted perplexity rise from rounding |
|---|---|---|---|
| Standard method, rounding (uniform 4-bit, nothing forgotten) | 13.0 MB | 4.00 | 0.1084 |
| Standard method, forgetting (H2O, SnapKV, InfiniGen: 16-bit, 20% of words kept) | 9.2 MB | 16.00 | 0.0000 |
| Plan (bits + forgetting) | 3.2 MB | 3.82 | 0.1084 |
| Plan, bits only | 12.8 MB | 3.95 | 0.1084 |

**What each column means**

- **Version**: Which KV cache plan the row describes.
- **Predicted memory (2048 words)**: Memory for the notes on one text of 2048 tokens (word pieces).
- **Average bits**: Bits per stored number, averaged over every layer's keys and values.
- **Predicted perplexity rise from rounding**: The measured per-layer damages of rounding added up. Forgetting is not included: Stage 3 measures it.

Choosing bits per layer predicts no accuracy gain over the standard method here: at this average the measured differences between layers are too small to use. The saving comes from forgetting, which Stage 3 has to confirm with a real eviction method.

Stage 3 adds the search parameter `quarot_k_bits` and checks the cache against `kv_budget_gb`.

## Stage 4: evaluation across backends

Stage 4 runs the compressed versions from Stages 1 to 3 on each backend (HF Transformers, llama.cpp, vLLM, TensorRT-LLM). From Stage 0 it takes the reference numbers of the uncompressed model and the conditions they were measured under, so every later number is comparable.

| Reference | Original model (uncompressed) |
|---|---|
| Perplexity, validation half | 10.18 |
| Perplexity, held-out half | 10.62 |
| Time to read a prompt (ms) | 5.858 |
| Time per word (ms) | 4.258 |
| Peak graphics-card memory (GB) | 2.414 |
| Size (GB) | 2.2 |
| KV cache memory (GB) | 0.04614 |

**What each column means**

- **Reference**: What was measured on the uncompressed model.
- **Original model (uncompressed)**: The value measured in this run (– if the measurement was skipped).

Conditions: wikitext2 test split in 512-token windows, first half for validation and second half held out (never tuned on); latency with a 128-token prompt and 64 generated tokens, 3 warm-up and 10 timed repeats (cuda graph timing); seed 0; backend HF Transformers.

## Search

The search tries many settings and keeps the best trade-offs. Stage 0's measurements are cached, so a trial that only changes the threshold or the share removed re-plans in milliseconds; a new calibration text or passage count costs one new measurement (122 s for this profile).

| Parameter | Used by stage | This run | Allowed values |
|---|---|---|---|
| sensitive_threshold | 0 | 0.5 | 0.1 to 0.9 |
| prune_ratio_aggressive | 0 | 0.3 | 0.0 to 0.6 |
| calib_dataset | 0 | wikitext2 | wikitext2, c4, pile10k |
| calib_samples | 0 | 64 | 16, 32, 64, 128 |
| gptq_groupsize | 1 | 128 | 32, 64, 128, -1 |
| smoothquant_alpha | 1 | 0.5 | 0.0 to 1.0 |
| quarot_k_bits | 3 | 4 | 2, 3, 4, 8 |

**What each column means**

- **Parameter**: A setting the search may change.
- **Used by stage**: The stage that reads it.
- **This run**: The value used for this report.
- **Allowed values**: The range or list the search picks from.

Per trial Stage 0 gives the search predicted size, average bits, share removed, sensitivity exposure and KV cache memory without running the model; perplexity and speed come from the stage that applies the plan. Held-out perplexity is reported for every trial but never optimised.

## Caveats

- Layer 0's sensitivity score stands far from the others; check it separately in Stage 2.
- Layer 1's sensitivity score stands far from the others; check it separately in Stage 2.
- Layer 2's sensitivity score stands far from the others; check it separately in Stage 2.
- Layer 7's sensitivity score stands far from the others; check it separately in Stage 2.
- Layer 21's sensitivity score stands far from the others; check it separately in Stage 2.
